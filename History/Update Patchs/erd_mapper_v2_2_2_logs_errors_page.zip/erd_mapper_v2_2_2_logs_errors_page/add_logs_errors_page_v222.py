
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py", "logger.py", "ui_logs.py",
]

LOGGER_PY = '\nfrom __future__ import annotations\n\nimport json\nimport traceback\nfrom datetime import UTC, datetime\nfrom pathlib import Path\nfrom typing import Any, Dict, List, Optional\n\nLOG_FILE = Path("erm_error_log.json")\nVALID_SEVERITIES = {"INFO", "WARNING", "ERROR", "CRITICAL"}\n\n\ndef _utc_now() -> str:\n    return datetime.now(UTC).isoformat()\n\n\ndef _normalise_severity(severity: str) -> str:\n    sev = (severity or "INFO").upper().strip()\n    return sev if sev in VALID_SEVERITIES else "INFO"\n\n\ndef _safe_details(details: Any) -> Any:\n    if details is None:\n        return ""\n    if isinstance(details, (str, int, float, bool, list, dict)):\n        return details\n    return str(details)\n\n\ndef read_logs(limit: Optional[int] = None) -> List[Dict[str, Any]]:\n    if not LOG_FILE.exists():\n        return []\n\n    try:\n        data = json.loads(LOG_FILE.read_text(encoding="utf-8"))\n        if not isinstance(data, list):\n            return []\n    except Exception:\n        return []\n\n    return data[-limit:] if limit else data\n\n\ndef write_logs(logs: List[Dict[str, Any]]) -> None:\n    LOG_FILE.write_text(json.dumps(logs, indent=2, ensure_ascii=False), encoding="utf-8")\n\n\ndef clear_logs() -> None:\n    write_logs([])\n\n\ndef log_event(severity: str, module: str, action: str, message: str, details: Any = "") -> Dict[str, Any]:\n    entry = {\n        "timestamp": _utc_now(),\n        "severity": _normalise_severity(severity),\n        "module": module or "Application",\n        "action": action or "",\n        "message": message or "",\n        "details": _safe_details(details),\n    }\n\n    logs = read_logs()\n    logs.append(entry)\n\n    if len(logs) > 2000:\n        logs = logs[-2000:]\n\n    write_logs(logs)\n    return entry\n\n\ndef log_info(module: str, action: str, message: str, details: Any = "") -> Dict[str, Any]:\n    return log_event("INFO", module, action, message, details)\n\n\ndef log_warning(module: str, action: str, message: str, details: Any = "") -> Dict[str, Any]:\n    return log_event("WARNING", module, action, message, details)\n\n\ndef log_error(module: str, action: str, message: str, details: Any = "") -> Dict[str, Any]:\n    return log_event("ERROR", module, action, message, details)\n\n\ndef log_critical(module: str, action: str, message: str, details: Any = "") -> Dict[str, Any]:\n    return log_event("CRITICAL", module, action, message, details)\n\n\ndef log_exception(module: str, action: str, message: str, exc: BaseException, details: Any = "") -> Dict[str, Any]:\n    payload = {\n        "error_type": type(exc).__name__,\n        "error": str(exc),\n        "traceback": traceback.format_exc(),\n        "details": _safe_details(details),\n    }\n    return log_event("ERROR", module, action, message, payload)\n'
UI_LOGS_PY = '\nfrom __future__ import annotations\n\nimport json\nfrom typing import Any, Dict, List\n\nimport pandas as pd\nimport streamlit as st\n\nfrom logger import clear_logs, read_logs\n\n\ndef _logs_to_dataframe(logs: List[Dict[str, Any]]) -> pd.DataFrame:\n    rows = []\n    for entry in logs:\n        details = entry.get("details", "")\n        if isinstance(details, (dict, list)):\n            details = json.dumps(details, ensure_ascii=False)\n        rows.append(\n            {\n                "timestamp": entry.get("timestamp", ""),\n                "severity": entry.get("severity", ""),\n                "module": entry.get("module", ""),\n                "action": entry.get("action", ""),\n                "message": entry.get("message", ""),\n                "details": details,\n            }\n        )\n    return pd.DataFrame(rows)\n\n\ndef render_logs_tab(state=None) -> None:\n    st.subheader("Logs & Errors")\n    st.caption("Review recent application events, warnings, and errors recorded locally for troubleshooting.")\n\n    logs = read_logs()\n\n    if not logs:\n        st.info("No logs recorded yet.")\n        return\n\n    df = _logs_to_dataframe(logs)\n\n    filter_col1, filter_col2, filter_col3 = st.columns(3)\n\n    with filter_col1:\n        severities = ["All"] + sorted([s for s in df["severity"].dropna().unique().tolist() if s])\n        selected_severity = st.selectbox(\n            "Severity",\n            severities,\n            help="Filter log entries by severity level.",\n            key="logs_filter_severity",\n        )\n\n    with filter_col2:\n        modules = ["All"] + sorted([m for m in df["module"].dropna().unique().tolist() if m])\n        selected_module = st.selectbox(\n            "Module",\n            modules,\n            help="Filter log entries by app module or page.",\n            key="logs_filter_module",\n        )\n\n    with filter_col3:\n        search_text = st.text_input(\n            "Search logs",\n            placeholder="Search message, action, or details",\n            help="Search across action, message, and details.",\n            key="logs_search_text",\n        )\n\n    filtered = df.copy()\n\n    if selected_severity != "All":\n        filtered = filtered[filtered["severity"] == selected_severity]\n\n    if selected_module != "All":\n        filtered = filtered[filtered["module"] == selected_module]\n\n    if search_text.strip():\n        needle = search_text.strip().lower()\n        filtered = filtered[\n            filtered.apply(\n                lambda row: needle in " ".join([str(v).lower() for v in row.values]).lower(),\n                axis=1,\n            )\n        ]\n\n    metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)\n    metric_col1.metric("Total logs", len(df))\n    metric_col2.metric("Filtered logs", len(filtered))\n    metric_col3.metric("Errors", int((df["severity"] == "ERROR").sum()))\n    metric_col4.metric("Critical", int((df["severity"] == "CRITICAL").sum()))\n\n    st.dataframe(filtered.sort_values("timestamp", ascending=False), width="stretch", hide_index=True)\n\n    download_col, clear_col = st.columns([2, 1])\n\n    with download_col:\n        st.download_button(\n            "Download logs JSON",\n            data=json.dumps(logs, indent=2, ensure_ascii=False),\n            file_name="erm_error_log.json",\n            mime="application/json",\n        )\n\n    with clear_col:\n        if st.button("Clear logs", type="secondary", help="Clear all local application logs."):\n            clear_logs()\n            st.success("Logs cleared.")\n            st.rerun()\n'
STARTUP_BLOCK = '    if not st.session_state.get("erm_startup_logged"):\n        try:\n            log_info("Application", "startup", "Entity Relation Mapper started")\n        except Exception:\n            pass\n        st.session_state["erm_startup_logged"] = True\n\n'
CHANGELOG_ENTRY = '{\n        "version": "v2.2.2 Patch",\n        "title": "Logs and Errors Page",\n        "changes": [\n            "Added logger.py for local JSON application logging.",\n            "Added ui_logs.py for a Logs & Errors page.",\n            "Added Logs & Errors tab to the main Streamlit app.",\n            "Added severity, module, and search filters for log review.",\n            "Added log download and clear-log actions.",\n            "Added erm_error_log.json to .gitignore.",\n            "Preserved existing app data model and saved-state compatibility."\n        ],\n    },'
CHANGELOG_MD_ENTRY = '## v2.2.2 Patch — Logs & Errors Page\n\n### Added\n- logger.py for local JSON application logging.\n- ui_logs.py for the Logs & Errors page.\n- Logs & Errors tab.\n- Severity, module, and search filters.\n- Download logs JSON button.\n- Clear logs action.\n- erm_error_log.json gitignore entry.\n\n### Preserved\n- Existing saved-state compatibility.\n- Existing schema, relationship, ERD, and export workflows.\n\n---\n'

def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")

def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")

def write_new_modules(app_dir: Path) -> None:
    write_text(app_dir / "logger.py", LOGGER_PY)
    write_text(app_dir / "ui_logs.py", UI_LOGS_PY)

def update_app(app_file: Path) -> None:
    text = read_text(app_file)

    if "from ui_logs import render_logs_tab" not in text:
        if "from ui_export import render_export_tab" in text:
            text = text.replace(
                "from ui_export import render_export_tab",
                "from ui_export import render_export_tab\nfrom ui_logs import render_logs_tab",
                1,
            )
        else:
            text = "from ui_logs import render_logs_tab\n" + text

    if "from logger import log_info" not in text:
        if "from ui_logs import render_logs_tab\n" in text:
            text = text.replace(
                "from ui_logs import render_logs_tab\n",
                "from ui_logs import render_logs_tab\nfrom logger import log_info, log_exception\n",
                1,
            )
        else:
            text = "from logger import log_info, log_exception\n" + text

    if "tab_logs" not in text:
        pattern = re.compile(
            r"(tab_contexts\s*,\s*tab_tables\s*,\s*tab_relationships\s*,\s*tab_infer\s*,\s*tab_erd\s*,\s*tab_export)\s*=\s*st\.tabs\(\[([\s\S]*?)\]\)",
            re.MULTILINE,
        )
        match = pattern.search(text)
        if match:
            current_vars = match.group(1)
            labels = match.group(2).rstrip()
            if "Logs & Errors" not in labels:
                labels = labels.rstrip()
                if labels.endswith(","):
                    labels = labels + '\n        "Logs & Errors",'
                else:
                    labels = labels + ',\n        "Logs & Errors"'
            replacement = current_vars + ", tab_logs = st.tabs([" + labels + "])"
            text = text[:match.start()] + replacement + text[match.end():]

    if "render_logs_tab(state)" not in text:
        pattern = re.compile(r"(with tab_export:\n\s+render_export_tab\(state\)\n)", re.MULTILINE)
        match = pattern.search(text)
        if match:
            text = text[:match.end()] + "\n    with tab_logs:\n        render_logs_tab(state)\n" + text[match.end():]
        else:
            marker = 'if __name__ == "__main__":'
            if marker in text:
                text = text.replace(marker, '    with tab_logs:\n        render_logs_tab(state)\n\n' + marker, 1)

    if 'st.session_state["erm_startup_logged"] = True' not in text:
        main_match = re.search(r"def main\(\) -> None:\n", text)
        if main_match:
            text = text[:main_match.end()] + STARTUP_BLOCK + text[main_match.end():]

    write_text(app_file, text)

def update_gitignore(path: Path) -> None:
    text = read_text(path) if path.exists() else ""
    if "erm_error_log.json" not in text:
        text = text.rstrip() + "\nerm_error_log.json\n"
    write_text(path, text)

def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.2"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Logs and Errors Page"',
        text,
        count=1,
    )
    if "v2.2.2 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)
    write_text(path, text)

def update_changelog(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "v2.2.2 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    write_text(path, text)

def update_version(path: Path) -> None:
    if not path.exists():
        return
    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.2 Patch\n\nVersion Name: Logs and Errors Page\n\nStatus: Logs & Errors tab added with local JSON application logging.\n",
    )

def update_readme(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "erm_error_log.json" not in text:
        text += "\n\n## Logs & Errors\n\nThe app records local troubleshooting events in `erm_error_log.json`. Use the Logs & Errors tab to filter, search, download, or clear log entries.\n"
    write_text(path, text)

def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")
    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("\nCompile check passed.")

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python add_logs_errors_page_v222.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    write_new_modules(app_dir)
    update_app(app_dir / "app.py")
    update_gitignore(app_dir / ".gitignore")
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    update_readme(app_dir / "README.md")
    compile_check(app_dir)
    print("\nPatch applied successfully.")
    print("Version: v2.2.2 Patch - Logs and Errors Page")

if __name__ == "__main__":
    main()
