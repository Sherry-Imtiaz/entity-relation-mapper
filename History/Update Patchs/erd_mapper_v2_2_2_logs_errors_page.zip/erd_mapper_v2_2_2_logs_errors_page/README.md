# Entity Relation Mapper — v2.2.2 Logs & Errors Page

This patch adds a local logging system and a Logs & Errors tab.

## Adds

- `logger.py`
- `ui_logs.py`
- `erm_error_log.json` support
- Logs & Errors tab
- Severity filter
- Module filter
- Search
- Download logs JSON
- Clear logs button
- `.gitignore` entry for `erm_error_log.json`

## How to apply

```bash
python add_logs_errors_page_v222.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate and run:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.2.2 Patch — Logs and Errors Page`
