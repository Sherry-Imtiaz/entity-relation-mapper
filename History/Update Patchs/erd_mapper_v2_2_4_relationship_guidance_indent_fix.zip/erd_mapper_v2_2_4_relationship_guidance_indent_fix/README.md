# Entity Relation Mapper — v2.2.4 Relationship Guidance Indentation Fix

This patch fixes:

```text
IndentationError: unindent does not match any outer indentation level (ui_relationships.py, line 180)
```

## Cause

The v2.2.3 relationship guidance patch inserted the suggestion panel at an inconsistent indentation level in `ui_relationships.py`.

## Fix

This patch replaces the affected manual relationship picklist form and guidance helpers with a clean, consistently indented implementation.

## How to apply

```bash
python fix_relationship_guidance_indent_v224.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate and run:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.2.4 Patch — Relationship Guidance Indentation Fix`
