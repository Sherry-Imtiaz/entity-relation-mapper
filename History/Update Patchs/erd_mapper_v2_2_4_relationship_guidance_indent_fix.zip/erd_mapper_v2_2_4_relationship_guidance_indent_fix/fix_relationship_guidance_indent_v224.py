
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py", "logger.py", "ui_logs.py",
    "relationship_guidance.py",
]

RELATIONSHIP_GUIDANCE_PY = '\nfrom __future__ import annotations\n\nfrom typing import Any, Dict, Optional\n\nfrom models import ColumnInfo, ErdState\n\n\ndef is_key_like_column_name(column_name: str) -> bool:\n    cname = (column_name or "").lower()\n    return (\n        cname == "id"\n        or cname.endswith("_id")\n        or cname.endswith("id")\n        or "_id_" in cname\n        or cname.endswith("_key")\n        or cname.endswith("key")\n        or "_key_" in cname\n        or cname.endswith("_code")\n        or cname.endswith("code")\n        or "_code_" in cname\n        or cname.endswith("_number")\n        or cname.endswith("number")\n        or "_number_" in cname\n        or cname.endswith("_no")\n        or cname.endswith("no")\n    )\n\n\ndef get_column_info(state: ErdState, full_table: str, column_name: str) -> Optional[ColumnInfo]:\n    table = state.tables.get(full_table)\n    if not table:\n        return None\n\n    for column in table.columns:\n        if column.column_name == column_name:\n            return column\n\n    return None\n\n\ndef suggest_relationship_options(\n    state: ErdState,\n    source_full_table: str,\n    source_column: str,\n    target_full_table: str,\n    target_column: str,\n    relationship_mode: str = "Standard relationship",\n) -> Dict[str, Any]:\n    source_info = get_column_info(state, source_full_table, source_column)\n    target_info = get_column_info(state, target_full_table, target_column)\n\n    source_pk = bool(getattr(source_info, "is_primary_key", False))\n    target_pk = bool(getattr(target_info, "is_primary_key", False))\n    source_key_like = source_pk or is_key_like_column_name(source_column)\n    target_key_like = target_pk or is_key_like_column_name(target_column)\n    matching_names = (source_column or "").lower() == (target_column or "").lower()\n    same_table = source_full_table == target_full_table\n    conditional = relationship_mode == "Conditional relationship"\n\n    suggestion = {\n        "cardinality": "many-to-one",\n        "join_type": "LEFT JOIN",\n        "confidence": 0.75,\n        "relationship_type": "conditional" if conditional else "manual",\n        "warning": "",\n        "reason": "Default recommendation for joining a detail/source table to a related target table.",\n    }\n\n    reasons = []\n\n    if same_table:\n        suggestion["warning"] = (\n            "Source and target are from the same table. This may be a self-join. "\n            "Confirm this is intentional before saving."\n        )\n        reasons.append("The source and target table are the same, so this may represent a self-join.")\n\n    if source_pk and target_pk:\n        suggestion.update(\n            {\n                "cardinality": "one-to-one",\n                "join_type": "INNER JOIN",\n                "confidence": 0.85,\n            }\n        )\n        reasons.append("Both selected columns appear to be primary keys, which often indicates a one-to-one relationship.")\n    elif target_pk or target_key_like:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.95 if (source_key_like or matching_names) else 0.90,\n            }\n        )\n        reasons.append("The target column appears to be a primary key or ID/key-like field.")\n        if source_key_like:\n            reasons.append("The source column also looks like an ID/key reference.")\n        if matching_names:\n            reasons.append("The source and target column names match.")\n    elif source_key_like and target_key_like:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.90,\n            }\n        )\n        reasons.append("Both selected columns look like ID/key-style fields.")\n    elif matching_names:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.85,\n            }\n        )\n        reasons.append("The source and target column names match.")\n\n    if conditional:\n        suggestion["join_type"] = "LEFT JOIN"\n        suggestion["confidence"] = max(float(suggestion["confidence"]), 0.90)\n        reasons.append(\n            "Conditional relationships commonly use LEFT JOIN so source records are preserved while the condition controls valid matches."\n        )\n        reasons.append(\n            "Use conditional relationships when a shared association table links to different module types using a discriminator field such as Item_Type."\n        )\n\n    suggestion["reason"] = " ".join(reasons) if reasons else suggestion["reason"]\n    return suggestion\n'
UI_RELATIONSHIP_BLOCK = '\ndef apply_pending_relationship_suggestions() -> None:\n    pending_map = {\n        "pending_manual_picklist_cardinality": "manual_picklist_cardinality",\n        "pending_manual_picklist_join_type": "manual_picklist_join_type",\n        "pending_manual_picklist_confidence": "manual_picklist_confidence",\n    }\n\n    for pending_key, widget_key in pending_map.items():\n        if pending_key in st.session_state:\n            st.session_state[widget_key] = st.session_state.pop(pending_key)\n\n\ndef render_relationship_suggestion_panel(\n    state: ErdState,\n    source_full: str,\n    source_col: str,\n    target_full: str,\n    target_col: str,\n    relationship_mode: str,\n) -> None:\n    suggestion = suggest_relationship_options(\n        state,\n        source_full,\n        source_col,\n        target_full,\n        target_col,\n        relationship_mode,\n    )\n\n    st.markdown("#### Suggested relationship options")\n\n    if suggestion.get("warning"):\n        st.warning(suggestion["warning"])\n\n    metric_col1, metric_col2, metric_col3 = st.columns(3)\n    metric_col1.metric("Suggested cardinality", suggestion["cardinality"])\n    metric_col2.metric("Suggested join", suggestion["join_type"])\n    metric_col3.metric("Suggested confidence", f\'{float(suggestion["confidence"]):.2f}\')\n\n    with st.expander("Why these options are suggested", expanded=False):\n        st.write(suggestion["reason"])\n\n    if st.button(\n        "Apply suggested options",\n        key="manual_picklist_apply_suggestion",\n        help="Apply the suggested cardinality, join type, and confidence to the relationship form.",\n    ):\n        st.session_state["pending_manual_picklist_cardinality"] = suggestion["cardinality"]\n        st.session_state["pending_manual_picklist_join_type"] = suggestion["join_type"]\n        st.session_state["pending_manual_picklist_confidence"] = float(suggestion["confidence"])\n\n        try:\n            from logger import log_info\n\n            log_info(\n                "Relationships",\n                "suggestion_applied",\n                "Relationship suggestion applied",\n                {\n                    "source": f"{source_full}.{source_col}",\n                    "target": f"{target_full}.{target_col}",\n                    "suggestion": suggestion,\n                },\n            )\n        except Exception:\n            pass\n\n        st.success("Suggested options applied.")\n        st.rerun()\n\n\ndef render_context_manual_relationship_picklist_form(state: ErdState) -> None:\n    st.markdown("### Add relationship from active context")\n    apply_pending_relationship_suggestions()\n\n    active_ctx = get_active_context(state)\n    if not active_ctx:\n        relationship_context_warning(state)\n        return\n\n    scoped_tables = get_context_tables(state, active_ctx.id)\n    if len(scoped_tables) < 2:\n        relationship_context_warning(state)\n        st.info("Add at least two tables to the active relationship context before creating relationships.")\n        return\n\n    st.info(f"Relationship creation scope: {active_ctx.name} - {len(scoped_tables)} assigned tables")\n\n    table_options = sorted(scoped_tables.keys(), key=str.lower)\n    schema_options = ["All schemas"] + sorted(\n        {scoped_tables[t].schema_name or "(no schema)" for t in table_options},\n        key=str.lower,\n    )\n\n    col_source, col_target = st.columns(2)\n\n    with col_source:\n        st.markdown("**Source**")\n        source_schema_filter = st.selectbox(\n            "Source schema filter",\n            schema_options,\n            key="manual_picklist_source_schema_filter",\n        )\n        source_search = st.text_input(\n            "Search source table",\n            placeholder="Type to filter source tables",\n            key="manual_picklist_source_search",\n        )\n\n        source_options = table_options\n        if source_schema_filter != "All schemas":\n            source_options = [\n                t for t in source_options\n                if (scoped_tables[t].schema_name or "(no schema)") == source_schema_filter\n            ]\n        if source_search.strip():\n            source_options = [\n                t for t in source_options\n                if source_search.strip().lower() in t.lower()\n            ]\n        if not source_options:\n            source_options = table_options\n\n        source_full = st.selectbox(\n            "Source table",\n            source_options,\n            key="manual_picklist_source_table",\n            help="The table where the relationship starts. Usually the child/detail table or the table containing the foreign key.",\n        )\n        source_columns = get_table_columns(state, source_full)\n        source_col = st.selectbox(\n            "Source column",\n            source_columns,\n            key="manual_picklist_source_column",\n            help="The source field used in the join. Often an ID or foreign-key-like field.",\n        )\n\n    with col_target:\n        st.markdown("**Target**")\n        target_schema_filter = st.selectbox(\n            "Target schema filter",\n            schema_options,\n            key="manual_picklist_target_schema_filter",\n        )\n        target_search = st.text_input(\n            "Search target table",\n            placeholder="Type to filter target tables",\n            key="manual_picklist_target_search",\n        )\n\n        target_options = table_options\n        if target_schema_filter != "All schemas":\n            target_options = [\n                t for t in target_options\n                if (scoped_tables[t].schema_name or "(no schema)") == target_schema_filter\n            ]\n        if target_search.strip():\n            target_options = [\n                t for t in target_options\n                if target_search.strip().lower() in t.lower()\n            ]\n        if not target_options:\n            target_options = table_options\n\n        target_full = st.selectbox(\n            "Target table",\n            target_options,\n            key="manual_picklist_target_table",\n            help="The table being joined to. Usually the parent, master, or reference table.",\n        )\n        target_columns = get_table_columns(state, target_full)\n        target_col = st.selectbox(\n            "Target column",\n            target_columns,\n            key="manual_picklist_target_column",\n            help="The matching field in the target table. Often a primary key or unique ID.",\n        )\n\n    options_col1, options_col2, options_col3 = st.columns(3)\n\n    with options_col1:\n        relationship_mode = st.selectbox(\n            "Relationship mode",\n            ["Standard relationship", "Conditional relationship"],\n            key="manual_picklist_relationship_mode",\n            help="Use Standard for direct joins. Use Conditional when an extra rule is required, such as src.Item_Type = 3.",\n        )\n    with options_col2:\n        cardinality = st.selectbox(\n            "Cardinality",\n            ["many-to-one", "one-to-many", "one-to-one", "many-to-many"],\n            key="manual_picklist_cardinality",\n            help="Describes how records relate between source and target tables. Many-to-one is common for detail-to-master joins.",\n        )\n    with options_col3:\n        join_type = st.selectbox(\n            "Join type",\n            ["LEFT JOIN", "INNER JOIN", "RIGHT JOIN", "FULL OUTER JOIN"],\n            key="manual_picklist_join_type",\n            help="LEFT JOIN keeps all source records. INNER JOIN only returns matching records.",\n        )\n\n    confidence = st.slider(\n        "Confidence",\n        min_value=0.0,\n        max_value=1.0,\n        value=st.session_state.get("manual_picklist_confidence", 1.0),\n        step=0.05,\n        key="manual_picklist_confidence",\n    )\n\n    render_relationship_suggestion_panel(\n        state,\n        source_full,\n        source_col,\n        target_full,\n        target_col,\n        relationship_mode,\n    )\n\n    condition_sql = ""\n    if relationship_mode == "Conditional relationship":\n        condition_sql = st.text_input(\n            "Condition SQL",\n            placeholder="Example: src.Item_Type = 3",\n            key="manual_picklist_condition_sql",\n            help="Extra rule required for this relationship to be valid. Use this for discriminator fields such as Item_Type.",\n        )\n\n    extra_join_sql = st.text_input(\n        "Extra Join SQL, optional",\n        placeholder="Example: src.ValidTo IS NULL",\n        key="manual_picklist_extra_join_sql",\n        help="Optional extra SQL filter for the join, such as active/current records only.",\n    )\n\n    description = st.text_area(\n        "Description / business meaning",\n        placeholder="Explain what this relationship means in business/database terms.",\n        key="manual_picklist_description",\n        help="Describe the business meaning of the relationship. This improves future SQL generation and review.",\n    )\n\n    with st.expander("Relationship preview", expanded=False):\n        preview = f"{source_full}.{source_col} -> {target_full}.{target_col}"\n        if condition_sql.strip():\n            preview += f"\\\\nCondition: {condition_sql}"\n        if extra_join_sql.strip():\n            preview += f"\\\\nExtra join: {extra_join_sql}"\n        st.code(preview, language="text")\n\n    if st.button("Add relationship from picklists", type="primary", key="manual_picklist_add_relationship"):\n        if source_full == target_full and source_col == target_col:\n            st.warning("Source and target are the same table/column. Confirm this is intentional before saving.")\n            return\n\n        ss, stbl = split_full_table(source_full)\n        ts, ttbl = split_full_table(target_full)\n        relationship_type = "conditional" if condition_sql.strip() else "manual"\n\n        rid = rel_id(\n            ss,\n            stbl,\n            source_col,\n            ts,\n            ttbl,\n            target_col,\n            relationship_type,\n            condition_sql,\n        )\n\n        state.relationships[rid] = Relationship(\n            id=rid,\n            context_id=active_ctx.id,\n            source_schema=ss,\n            source_table=stbl,\n            source_column=source_col,\n            target_schema=ts,\n            target_table=ttbl,\n            target_column=target_col,\n            relationship_type=relationship_type,\n            cardinality=cardinality,\n            join_type=join_type,\n            confidence=confidence,\n            condition_sql=condition_sql,\n            extra_join_sql=extra_join_sql,\n            description=description,\n        )\n\n        save_state(state)\n\n        try:\n            from logger import log_info\n\n            log_info(\n                "Relationships",\n                "relationship_added",\n                "Relationship added from picklist form",\n                {\n                    "context": active_ctx.name,\n                    "source": f"{source_full}.{source_col}",\n                    "target": f"{target_full}.{target_col}",\n                    "relationship_type": relationship_type,\n                },\n            )\n        except Exception:\n            pass\n\n        st.success("Relationship added to the active context.")\n        st.rerun()\n'
CHANGELOG_ENTRY = '{\n        "version": "v2.2.4 Patch",\n        "title": "Relationship Guidance Indentation Fix",\n        "changes": [\n            "Fixed IndentationError in ui_relationships.py introduced by the relationship guidance patch.",\n            "Replaced the manual relationship picklist form with a clean, consistently indented implementation.",\n            "Preserved relationship suggestion guidance, Apply Suggested Options, and logging behaviour.",\n            "Re-ran compile validation across the modular project files."\n        ],\n    },'
CHANGELOG_MD_ENTRY = '## v2.2.4 Patch — Relationship Guidance Indentation Fix\n\n### Fixed\n- Fixed `IndentationError` in `ui_relationships.py`.\n- Replaced the affected manual relationship picklist form with a clean implementation.\n- Preserved suggestion guidance and Apply Suggested Options behaviour.\n\n---\n'


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def remove_top_level_function(text: str, function_name: str) -> str:
    pattern = re.compile(
        r"^def " + re.escape(function_name) + r"\([\s\S]*?(?=^def |\Z)",
        re.MULTILINE,
    )
    return pattern.sub("", text)


def update_relationship_guidance(app_dir: Path) -> None:
    write_text(app_dir / "relationship_guidance.py", RELATIONSHIP_GUIDANCE_PY)


def update_ui_relationships(path: Path) -> None:
    text = read_text(path)

    if "from relationship_guidance import suggest_relationship_options" not in text:
        if "from ui_shared import *" in text:
            text = text.replace(
                "from ui_shared import *",
                "from ui_shared import *\nfrom relationship_guidance import suggest_relationship_options",
                1,
            )
        else:
            text = "from relationship_guidance import suggest_relationship_options\n" + text

    for fn in [
        "apply_pending_relationship_suggestions",
        "render_relationship_suggestion_panel",
        "render_context_manual_relationship_picklist_form",
    ]:
        text = remove_top_level_function(text, fn)

    text = text.rstrip() + "\n\n" + UI_RELATIONSHIP_BLOCK

    if "render_context_manual_relationship_picklist_form(state)" not in text:
        marker = 'st.subheader("Relationship registry")'
        if marker in text:
            text = text.replace(
                marker,
                marker + '\n        render_context_manual_relationship_picklist_form(state)\n        st.divider()',
                1,
            )
        else:
            marker = "def render_relationships_tab(state: ErdState) -> None:\n"
            if marker in text:
                text = text.replace(
                    marker,
                    marker + '    render_context_manual_relationship_picklist_form(state)\n    st.divider()\n',
                    1,
                )

    write_text(path, text)


def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.4"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Relationship Guidance Indentation Fix"',
        text,
        count=1,
    )
    if "v2.2.4 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)
    write_text(path, text)


def update_changelog(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "v2.2.4 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    write_text(path, text)


def update_version(path: Path) -> None:
    if not path.exists():
        return
    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.4 Patch\n\nVersion Name: Relationship Guidance Indentation Fix\n\nStatus: Relationship guidance form indentation repaired and compile validation restored.\n",
    )


def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            if filename in {"logger.py", "ui_logs.py"}:
                continue
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python fix_relationship_guidance_indent_v224.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()

    update_relationship_guidance(app_dir)
    update_ui_relationships(app_dir / "ui_relationships.py")
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.4 Patch - Relationship Guidance Indentation Fix")


if __name__ == "__main__":
    main()
