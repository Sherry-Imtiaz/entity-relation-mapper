
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path


PYTHON_FILES = [
    "app.py",
    "config.py",
    "models.py",
    "state_manager.py",
    "importers.py",
    "validation.py",
    "inference.py",
    "exports.py",
    "visualisation.py",
    "ui_shared.py",
    "ui_contexts.py",
    "ui_tables.py",
    "ui_relationships.py",
    "ui_inference.py",
    "ui_erd.py",
    "ui_export.py",
    "logger.py",
    "ui_logs.py",
    "relationship_guidance.py",
    "quality_checks.py",
]


CHANGELOG_ENTRY = """{
        "version": "v2.2.8 Patch",
        "title": "Export Quality Helper Import Fix",
        "changes": [
            "Fixed NameError in ui_export.py where report_to_issue_rows was not available to the export quality panel helper.",
            "Moved the quality_checks imports to module scope where helper functions can access them.",
            "Preserved export readiness checklist and context completeness scoring.",
            "Re-ran compile validation across the modular project files."
        ],
    },"""


CHANGELOG_MD_ENTRY = """## v2.2.8 Patch — Export Quality Helper Import Fix

### Fixed
- Fixed `NameError: name 'report_to_issue_rows' is not defined` in `ui_export.py`.
- Made `report_to_issue_rows` available to `_render_export_quality_panel()`.

### Preserved
- Export readiness checklist.
- Relationship completeness score.
- Context quality summary.
- Existing export workflows.

---
"""


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def fix_ui_export(path: Path) -> None:
    text = read_text(path)

    # Normalise line endings.
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # Ensure from __future__ stays first.
    future_line = "from __future__ import annotations"
    lines = [line for line in text.split("\n") if line.strip() != future_line]
    while lines and not lines[0].strip():
        lines.pop(0)
    text = future_line + "\n\n" + "\n".join(lines).lstrip("\n")

    # Remove local import inside render_export_tab if present.
    text = text.replace(
        "    from quality_checks import build_export_quality_report, report_to_issue_rows\n\n",
        "",
    )
    text = text.replace(
        "    from quality_checks import build_export_quality_report, report_to_issue_rows\n",
        "",
    )

    # Add module-level import after normal imports if missing.
    import_line = "from quality_checks import build_export_quality_report, report_to_issue_rows"
    if import_line not in text:
        # Insert after existing project imports where possible; otherwise after standard imports.
        markers = [
            "from exports import",
            "from validation import",
            "from ui_shared import",
        ]

        insert_at = None
        for marker in markers:
            idx = text.find(marker)
            if idx != -1:
                # Insert after the full line or import block line.
                line_end = text.find("\n", idx)
                if line_end != -1:
                    insert_at = line_end + 1

        if insert_at is None:
            # After future import and blank line.
            insert_at = len(future_line) + 2

        text = text[:insert_at] + import_line + "\n" + text[insert_at:]

    # Also make helper robust by adding an internal fallback import if the module-level import is ever removed.
    helper_signature = "def _render_export_quality_panel(report: dict) -> None:\n"
    fallback = "    from quality_checks import report_to_issue_rows\n\n"
    if helper_signature in text and fallback not in text:
        text = text.replace(helper_signature, helper_signature + fallback, 1)

    write_text(path, text.rstrip() + "\n")


def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")

    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.8"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Export Quality Helper Import Fix"',
        text,
        count=1,
    )

    if "v2.2.8 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)

    write_text(path, text)


def update_changelog(path: Path) -> None:
    if not path.exists():
        return

    text = read_text(path)
    if "v2.2.8 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)

    write_text(path, text)


def update_version(path: Path) -> None:
    if not path.exists():
        return

    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.8 Patch\n\nVersion Name: Export Quality Helper Import Fix\n\nStatus: Export quality helper import repaired and export readiness panel preserved.\n",
    )


def compile_check(app_dir: Path) -> None:
    errors = []

    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            if filename in {"logger.py", "ui_logs.py", "relationship_guidance.py", "quality_checks.py"}:
                continue
            errors.append(f"Missing file: {filename}")
            continue

        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)

    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python fix_export_quality_helper_import_v228.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    ui_export_file = app_dir / "ui_export.py"

    if not ui_export_file.exists():
        raise FileNotFoundError(f"Missing ui_export.py: {ui_export_file}")

    fix_ui_export(ui_export_file)
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.8 Patch - Export Quality Helper Import Fix")


if __name__ == "__main__":
    main()
