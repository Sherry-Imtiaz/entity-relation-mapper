# Entity Relation Mapper — v2.2.8 Export Quality Helper Import Fix

This patch fixes:

```text
NameError: name 'report_to_issue_rows' is not defined
```

## Cause

`report_to_issue_rows()` was imported inside `render_export_tab()`, but `_render_export_quality_panel()` is a separate helper function and cannot access that local import.

## How to apply

```bash
python fix_export_quality_helper_import_v228.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate and run:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.2.8 Patch — Export Quality Helper Import Fix`
