# Entity Relation Mapper — v2.1.7 ERD Visual Simplification

This patch removes Streamlit Flow from the ERD View and makes Graphviz the main ERD visualisation.

## What it changes

- Graphviz becomes the primary ERD visualisation.
- Mermaid remains text/export only.
- Streamlit Flow is removed from ERD View.
- `streamlit-flow-component` is removed from `requirements.txt`.
- Mermaid and Graphviz table schemas show a maximum of 10 fields per table.
- Primary key and ID/key-like fields are prioritised.

## How to apply

```bash
python erd_visual_simplification_v217.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.1.7 Patch — ERD Visual Simplification`
