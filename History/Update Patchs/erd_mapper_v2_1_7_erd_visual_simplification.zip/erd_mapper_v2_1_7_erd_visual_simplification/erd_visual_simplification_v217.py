
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py",
]

EXPORT_OVERRIDE_BLOCK = '\n# -----------------------------------------------------------------------------\n# v2.1.7 ERD visual simplification overrides\n# -----------------------------------------------------------------------------\n# These functions override earlier export_mermaid/export_dot definitions.\n\ndef _erd_is_key_like_column(column_name: str, is_primary_key: bool = False) -> bool:\n    cname = (column_name or "").lower()\n    return (\n        is_primary_key\n        or cname == "id"\n        or cname.endswith("_id")\n        or cname.endswith("id")\n        or "_id_" in cname\n        or cname.endswith("_key")\n        or cname.endswith("key")\n        or "_key_" in cname\n        or cname.endswith("_code")\n        or cname.endswith("code")\n        or "_code_" in cname\n        or cname.endswith("_number")\n        or cname.endswith("number")\n        or "_number_" in cname\n        or cname.endswith("_no")\n        or cname.endswith("no")\n    )\n\n\ndef _erd_display_columns(table: TableInfo, max_fields: int = 10) -> List[Any]:\n    columns = sorted(table.columns, key=lambda x: x.ordinal_position)\n    primary_columns = [c for c in columns if getattr(c, "is_primary_key", False)]\n    key_columns = [\n        c for c in columns\n        if c not in primary_columns\n        and _erd_is_key_like_column(getattr(c, "column_name", ""), getattr(c, "is_primary_key", False))\n    ]\n    other_columns = [c for c in columns if c not in primary_columns and c not in key_columns]\n    return (primary_columns + key_columns + other_columns)[:max_fields]\n\n\ndef _safe_mermaid_identifier(value: str) -> str:\n    safe = re.sub(r"[^A-Za-z0-9_]", "_", value or "")\n    if not safe:\n        safe = "unknown"\n    if safe[0].isdigit():\n        safe = "_" + safe\n    return safe\n\n\ndef _safe_mermaid_type(value: str) -> str:\n    safe = re.sub(r"[^A-Za-z0-9_]", "_", value or "string")\n    return safe or "string"\n\n\ndef _safe_dot_label(value: str) -> str:\n    return (value or "").replace("\\\\", "\\\\\\\\").replace(\'"\', r\'\\"\')\n\n\ndef export_mermaid(state: ErdState, only_active: bool = True) -> str:\n    lines = ["erDiagram"]\n\n    for table in sorted(state.tables.values(), key=lambda x: x.full_name.lower()):\n        entity_name = _safe_mermaid_identifier(table.full_name)\n        lines.append(f"    {entity_name} {{")\n        for column in _erd_display_columns(table, max_fields=10):\n            data_type = _safe_mermaid_type(getattr(column, "data_type", "") or "string")\n            column_name = _safe_mermaid_identifier(getattr(column, "column_name", ""))\n            pk_marker = " PK" if getattr(column, "is_primary_key", False) else ""\n            lines.append(f"        {data_type} {column_name}{pk_marker}")\n        lines.append("    }")\n\n    rels = [r for r in state.relationships.values() if (r.active or not only_active)]\n    for rel in rels:\n        if rel.source_full_table not in state.tables or rel.target_full_table not in state.tables:\n            continue\n        source_entity = _safe_mermaid_identifier(rel.source_full_table)\n        target_entity = _safe_mermaid_identifier(rel.target_full_table)\n        label = f"{rel.source_column} to {rel.target_column}"\n        if rel.condition_sql:\n            label += " conditional"\n        lines.append(f\'    {source_entity} ||--o{{ {target_entity} : "{label}"\')\n\n    return chr(10).join(lines)\n\n\ndef export_dot(state: ErdState, only_active: bool = True) -> str:\n    lines = [\n        "digraph ERD {",\n        "  graph [rankdir=LR, splines=ortho, nodesep=0.7, ranksep=0.9];",\n        "  node [shape=record, fontsize=10, fontname=\\"Arial\\"];",\n        "  edge [fontsize=9, fontname=\\"Arial\\"];",\n    ]\n\n    for table in sorted(state.tables.values(), key=lambda x: x.full_name.lower()):\n        node_id = re.sub(r"[^A-Za-z0-9_]", "_", table.full_name)\n        cols = []\n        for column in _erd_display_columns(table, max_fields=10):\n            col_name = _safe_dot_label(getattr(column, "column_name", ""))\n            prefix = "* " if getattr(column, "is_primary_key", False) else ""\n            if not getattr(column, "is_primary_key", False) and _erd_is_key_like_column(col_name):\n                prefix = "key "\n            cols.append(f"{prefix}{col_name}")\n\n        if not cols:\n            cols.append("_no_columns_loaded_")\n\n        label = "{" + _safe_dot_label(table.full_name) + "|" + "\\\\l".join(cols) + "\\\\l}"\n        lines.append(f\'  {node_id} [label="{label}"];\')\n\n    rels = [r for r in state.relationships.values() if (r.active or not only_active)]\n    for rel in rels:\n        if rel.source_full_table not in state.tables or rel.target_full_table not in state.tables:\n            continue\n        src = re.sub(r"[^A-Za-z0-9_]", "_", rel.source_full_table)\n        tgt = re.sub(r"[^A-Za-z0-9_]", "_", rel.target_full_table)\n        label = _safe_dot_label(f"{rel.source_column} -> {rel.target_column}")\n        if rel.condition_sql:\n            label += " [conditional]"\n        lines.append(f\'  {src} -> {tgt} [label="{label}"];\')\n\n    lines.append("}")\n    return chr(10).join(lines)\n'
UI_ERD_OVERRIDE_BLOCK = '\n# -----------------------------------------------------------------------------\n# v2.1.7 ERD visual simplification override\n# -----------------------------------------------------------------------------\n\ndef render_erd_tab(state: ErdState) -> None:\n    st.subheader("ERD View")\n\n    only_active = st.checkbox("Only active relationships", value=True, key="erd_only_active")\n    active_ctx = get_active_context(state)\n\n    erd_scope_options = ["Whole database", "Active relationship context"]\n    erd_scope = st.radio(\n        "ERD scope",\n        erd_scope_options,\n        index=1 if active_ctx else 0,\n        horizontal=True,\n    )\n\n    if not state.tables:\n        st.info("Load tables first.")\n        return\n\n    display_state = state\n    if erd_scope == "Active relationship context":\n        if active_ctx:\n            display_state = build_context_scoped_state(state, active_ctx.id)\n            st.info(f"Showing ERD for context: {active_ctx.name}")\n        else:\n            st.warning("No active context selected. Showing whole database instead.")\n\n    st.caption(\n        "Graphviz ERD view. Table nodes show a compact schema preview with a maximum of 10 prioritised fields per table."\n    )\n\n    dot = export_dot(display_state, only_active=only_active)\n    st.graphviz_chart(dot, width="stretch")\n\n    with st.expander("Graphviz DOT source and download"):\n        st.code(dot, language="dot")\n        st.download_button(\n            "Download Graphviz DOT",\n            data=dot,\n            file_name="erd_graphviz.dot",\n            mime="text/plain",\n        )\n\n    with st.expander("Mermaid ERD text and download"):\n        mermaid = export_mermaid(display_state, only_active=only_active)\n        st.code(mermaid, language="mermaid")\n        st.download_button(\n            "Download Mermaid ERD",\n            data=mermaid,\n            file_name="erd_mermaid.mmd",\n            mime="text/plain",\n        )\n'

def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")

def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")

def append_or_replace_block(path: Path, marker: str, block: str) -> None:
    text = read_text(path)
    if marker in text:
        text = text[:text.index(marker)].rstrip() + "\n\n" + block
    else:
        text = text.rstrip() + "\n\n" + block
    write_text(path, text)

def update_requirements(path: Path) -> None:
    if not path.exists():
        return
    lines = [line for line in read_text(path).splitlines() if line.strip().lower() != "streamlit-flow-component"]
    write_text(path, "\n".join(lines).rstrip() + "\n")

def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.1.7"', text, count=1)
    text = re.sub(r'APP_VERSION_NAME\s*=\s*"[^"]+"', 'APP_VERSION_NAME = "ERD Visual Simplification"', text, count=1)
    entry = '''{
        "version": "v2.1.7 Patch",
        "title": "ERD Visual Simplification",
        "changes": [
            "Removed Streamlit Flow as the active ERD visual component.",
            "Restored Graphviz as the main ERD visualisation.",
            "Kept Mermaid as text/export only.",
            "Updated Mermaid and Graphviz ERD output to show a maximum of 10 fields per table.",
            "Prioritised primary keys and ID/key-like fields in ERD table schema display.",
            "Removed streamlit-flow-component from requirements.txt."
        ],
    },'''
    if "v2.1.7 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + entry, 1)
    write_text(path, text)

def update_version_file(path: Path) -> None:
    if path.exists():
        write_text(path, "# Version\n\nCurrent Version: v2.1.7 Patch\n\nVersion Name: ERD Visual Simplification\n\nStatus: Graphviz is the primary ERD visualisation. Mermaid remains text/export only. Streamlit Flow visual component removed from the ERD View workflow.\n")

def update_changelog_file(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    entry = "## v2.1.7 Patch — ERD Visual Simplification\n\n### Added\n- Key/ID field prioritisation for Mermaid and Graphviz ERD output.\n- Maximum 10 displayed fields per table in ERD schemas.\n\n### Changed\n- ERD View now uses Graphviz as the main visualisation.\n- Mermaid and Graphviz ERDs are simplified to show relevant schema fields only.\n\n### Removed\n- Streamlit Flow visual component from the ERD View workflow.\n- streamlit-flow-component dependency from requirements.txt.\n\n---\n"
    if "v2.1.7 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + entry, 1)
    write_text(path, text)

def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")
    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("\nCompile check passed.")

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python erd_visual_simplification_v217.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    append_or_replace_block(app_dir / "exports.py", "# -----------------------------------------------------------------------------\n# v2.1.7 ERD visual simplification overrides", EXPORT_OVERRIDE_BLOCK)
    append_or_replace_block(app_dir / "ui_erd.py", "# -----------------------------------------------------------------------------\n# v2.1.7 ERD visual simplification override", UI_ERD_OVERRIDE_BLOCK)
    update_config(app_dir / "config.py")
    update_requirements(app_dir / "requirements.txt")
    update_version_file(app_dir / "VERSION.md")
    update_changelog_file(app_dir / "CHANGELOG.md")
    compile_check(app_dir)
    print("\nPatch applied successfully.")
    print("Version: v2.1.7 Patch - ERD Visual Simplification")

if __name__ == "__main__":
    main()
