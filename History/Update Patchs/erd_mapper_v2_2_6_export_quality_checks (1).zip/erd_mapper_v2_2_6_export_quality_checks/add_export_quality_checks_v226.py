
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py", "logger.py", "ui_logs.py",
    "relationship_guidance.py", "quality_checks.py",
]

QUALITY_CHECKS_PY = '\nfrom __future__ import annotations\n\nfrom typing import Any, Dict, List, Optional, Set, Tuple\n\nfrom models import ErdState, Relationship, TableInfo\n\n\ndef _full_table(schema_name: str, table_name: str) -> str:\n    schema = (schema_name or "").strip()\n    table = (table_name or "").strip()\n    return f"{schema}.{table}" if schema else table\n\n\ndef _relationship_tables(rel: Relationship) -> Tuple[str, str]:\n    source_full = getattr(rel, "source_full_table", None) or _full_table(\n        getattr(rel, "source_schema", ""),\n        getattr(rel, "source_table", ""),\n    )\n    target_full = getattr(rel, "target_full_table", None) or _full_table(\n        getattr(rel, "target_schema", ""),\n        getattr(rel, "target_table", ""),\n    )\n    return source_full, target_full\n\n\ndef _context_tables(state: ErdState, context_id: Optional[str]) -> Dict[str, TableInfo]:\n    if not context_id:\n        return dict(state.tables)\n\n    context = state.relationship_contexts.get(context_id)\n    if not context:\n        return {}\n\n    table_keys = set(getattr(context, "table_keys", []) or [])\n    if not table_keys:\n        table_keys = set(getattr(context, "tables", []) or [])\n\n    return {key: table for key, table in state.tables.items() if key in table_keys}\n\n\ndef _context_relationships(state: ErdState, context_id: Optional[str]) -> Dict[str, Relationship]:\n    if not context_id:\n        return dict(state.relationships)\n\n    return {\n        rel_id: rel\n        for rel_id, rel in state.relationships.items()\n        if getattr(rel, "context_id", "") == context_id\n    }\n\n\ndef build_export_quality_report(state: ErdState, context_id: Optional[str] = None) -> Dict[str, Any]:\n    tables = _context_tables(state, context_id)\n    relationships = _context_relationships(state, context_id)\n\n    table_keys: Set[str] = set(tables.keys())\n    relationship_table_keys: Set[str] = set()\n\n    broken_relationships: List[Dict[str, Any]] = []\n    missing_descriptions: List[Dict[str, Any]] = []\n    conditional_missing_condition: List[Dict[str, Any]] = []\n\n    active_relationships = []\n    conditional_relationships = []\n\n    for rel in relationships.values():\n        source_full, target_full = _relationship_tables(rel)\n        is_active = bool(getattr(rel, "active", True))\n        rel_type = (getattr(rel, "relationship_type", "") or "").lower()\n        condition_sql = (getattr(rel, "condition_sql", "") or "").strip()\n\n        if is_active:\n            active_relationships.append(rel)\n\n        if rel_type == "conditional" or condition_sql:\n            conditional_relationships.append(rel)\n            if not condition_sql:\n                conditional_missing_condition.append(\n                    {\n                        "relationship_id": getattr(rel, "id", ""),\n                        "issue": "Conditional relationship is missing condition SQL.",\n                        "source": source_full,\n                        "target": target_full,\n                    }\n                )\n\n        if source_full in table_keys:\n            relationship_table_keys.add(source_full)\n        if target_full in table_keys:\n            relationship_table_keys.add(target_full)\n\n        if source_full not in table_keys or target_full not in table_keys:\n            broken_relationships.append(\n                {\n                    "relationship_id": getattr(rel, "id", ""),\n                    "issue": "Relationship references a table outside the export scope or a missing table.",\n                    "source": source_full,\n                    "target": target_full,\n                    "source_found": source_full in table_keys,\n                    "target_found": target_full in table_keys,\n                }\n            )\n\n        if not (getattr(rel, "description", "") or "").strip():\n            missing_descriptions.append(\n                {\n                    "relationship_id": getattr(rel, "id", ""),\n                    "source": source_full,\n                    "target": target_full,\n                    "issue": "Relationship is missing a business description.",\n                }\n            )\n\n    tables_without_relationships = sorted(table_keys - relationship_table_keys)\n\n    columns_included = sum(len(getattr(table, "columns", []) or []) for table in tables.values())\n\n    context = state.relationship_contexts.get(context_id) if context_id else None\n\n    report = {\n        "context_id": context_id or "",\n        "context_name": getattr(context, "name", "Whole database") if context else "Whole database",\n        "context_type": getattr(context, "context_type", "") if context else "",\n        "tables_included": len(tables),\n        "columns_included": columns_included,\n        "relationships_included": len(relationships),\n        "active_relationships": len(active_relationships),\n        "conditional_relationships": len(conditional_relationships),\n        "broken_relationships": broken_relationships,\n        "broken_relationship_count": len(broken_relationships),\n        "tables_without_relationships": tables_without_relationships,\n        "tables_without_relationship_count": len(tables_without_relationships),\n        "relationships_missing_descriptions": missing_descriptions,\n        "relationships_missing_descriptions_count": len(missing_descriptions),\n        "conditional_relationships_missing_condition_sql": conditional_missing_condition,\n        "conditional_relationships_missing_condition_sql_count": len(conditional_missing_condition),\n    }\n\n    report["score"] = score_export_quality(report)\n    report["status"] = quality_status_label(report["score"])\n    report["warnings"] = build_quality_warnings(report)\n\n    return report\n\n\ndef score_export_quality(report: Dict[str, Any]) -> int:\n    score = 100\n\n    if report.get("tables_included", 0) == 0:\n        return 0\n\n    if report.get("broken_relationship_count", 0) > 0:\n        score -= 20\n\n    if report.get("relationships_included", 0) == 0:\n        score -= 15\n\n    if report.get("tables_without_relationship_count", 0) > 0:\n        score -= 10\n\n    if report.get("relationships_missing_descriptions_count", 0) > 0:\n        score -= 10\n\n    if report.get("conditional_relationships_missing_condition_sql_count", 0) > 0:\n        score -= 10\n\n    return max(0, min(100, score))\n\n\ndef quality_status_label(score: int) -> str:\n    if score >= 90:\n        return "Excellent"\n    if score >= 75:\n        return "Good"\n    if score >= 50:\n        return "Needs Review"\n    return "Incomplete"\n\n\ndef build_quality_warnings(report: Dict[str, Any]) -> List[str]:\n    warnings: List[str] = []\n\n    if report.get("tables_included", 0) == 0:\n        warnings.append("No tables are included in the export scope.")\n\n    if report.get("relationships_included", 0) == 0:\n        warnings.append("No relationships are included. SQL guidance may be incomplete.")\n\n    if report.get("broken_relationship_count", 0) > 0:\n        warnings.append("Some relationships reference missing or out-of-scope tables.")\n\n    if report.get("tables_without_relationship_count", 0) > 0:\n        warnings.append("Some included tables are not connected by relationships.")\n\n    if report.get("relationships_missing_descriptions_count", 0) > 0:\n        warnings.append("Some relationships are missing business descriptions.")\n\n    if report.get("conditional_relationships_missing_condition_sql_count", 0) > 0:\n        warnings.append("Some conditional relationships are missing condition SQL.")\n\n    return warnings\n\n\ndef report_to_issue_rows(report: Dict[str, Any]) -> List[Dict[str, Any]]:\n    rows: List[Dict[str, Any]] = []\n\n    for table_name in report.get("tables_without_relationships", []):\n        rows.append(\n            {\n                "category": "Table without relationship",\n                "item": table_name,\n                "issue": "Table is included in the export but has no mapped relationship.",\n            }\n        )\n\n    for item in report.get("broken_relationships", []):\n        rows.append(\n            {\n                "category": "Broken relationship",\n                "item": item.get("relationship_id", ""),\n                "issue": item.get("issue", ""),\n                "source": item.get("source", ""),\n                "target": item.get("target", ""),\n            }\n        )\n\n    for item in report.get("relationships_missing_descriptions", []):\n        rows.append(\n            {\n                "category": "Missing relationship description",\n                "item": item.get("relationship_id", ""),\n                "issue": item.get("issue", ""),\n                "source": item.get("source", ""),\n                "target": item.get("target", ""),\n            }\n        )\n\n    for item in report.get("conditional_relationships_missing_condition_sql", []):\n        rows.append(\n            {\n                "category": "Missing condition SQL",\n                "item": item.get("relationship_id", ""),\n                "issue": item.get("issue", ""),\n                "source": item.get("source", ""),\n                "target": item.get("target", ""),\n            }\n        )\n\n    return rows\n'
UI_EXPORT_OVERRIDE = '\n# -----------------------------------------------------------------------------\n# v2.2.6 Export quality checks override\n# -----------------------------------------------------------------------------\n\n\ndef _safe_call_export(fn, *args, **kwargs):\n    try:\n        return fn(*args, **kwargs)\n    except TypeError:\n        try:\n            return fn(*args)\n        except TypeError:\n            return fn(args[0])\n\n\ndef _get_active_context_for_export(state: ErdState):\n    active_id = getattr(state, "active_context_id", "")\n    if active_id and active_id in getattr(state, "relationship_contexts", {}):\n        return state.relationship_contexts[active_id]\n    return None\n\n\ndef _build_export_state_for_scope(state: ErdState, scope: str):\n    active_ctx = _get_active_context_for_export(state)\n    if scope == "Active relationship context" and active_ctx:\n        try:\n            return build_context_scoped_state(state, active_ctx.id), active_ctx.id, active_ctx.name\n        except Exception:\n            return state, active_ctx.id, active_ctx.name\n    return state, None, "Whole database"\n\n\ndef _render_export_quality_panel(report: dict) -> None:\n    st.markdown("### Export readiness")\n\n    score = int(report.get("score", 0))\n    status = report.get("status", "Unknown")\n\n    metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)\n    metric_col1.metric("Readiness score", f"{score}%")\n    metric_col2.metric("Status", status)\n    metric_col3.metric("Tables", report.get("tables_included", 0))\n    metric_col4.metric("Relationships", report.get("relationships_included", 0))\n\n    detail_col1, detail_col2, detail_col3, detail_col4 = st.columns(4)\n    detail_col1.metric("Columns", report.get("columns_included", 0))\n    detail_col2.metric("Active relationships", report.get("active_relationships", 0))\n    detail_col3.metric("Conditional relationships", report.get("conditional_relationships", 0))\n    detail_col4.metric("Broken links", report.get("broken_relationship_count", 0))\n\n    issue_col1, issue_col2, issue_col3 = st.columns(3)\n    issue_col1.metric("Tables without relationships", report.get("tables_without_relationship_count", 0))\n    issue_col2.metric("Missing descriptions", report.get("relationships_missing_descriptions_count", 0))\n    issue_col3.metric(\n        "Missing condition SQL",\n        report.get("conditional_relationships_missing_condition_sql_count", 0),\n    )\n\n    warnings = report.get("warnings", [])\n    if warnings:\n        st.warning("This export may be incomplete. Review the issues below before using the output for SQL generation.")\n        for warning in warnings:\n            st.caption(f"- {warning}")\n    else:\n        st.success("Export readiness checks look good.")\n\n    rows = report_to_issue_rows(report)\n    if rows:\n        with st.expander("Review export quality issues", expanded=False):\n            st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)\n\n\ndef _fallback_markdown_export(state: ErdState) -> str:\n    lines = ["# Database Context Export", ""]\n    lines.append("## Tables")\n    for table in sorted(state.tables.values(), key=lambda t: t.full_name.lower()):\n        lines.append(f"### {table.full_name}")\n        for col in sorted(table.columns, key=lambda c: c.ordinal_position):\n            pk = " PK" if getattr(col, "is_primary_key", False) else ""\n            lines.append(f"- {col.column_name}: {col.data_type}{pk}")\n        lines.append("")\n\n    lines.append("## Relationships")\n    for rel in state.relationships.values():\n        source_full = getattr(rel, "source_full_table", None) or f"{rel.source_schema}.{rel.source_table}"\n        target_full = getattr(rel, "target_full_table", None) or f"{rel.target_schema}.{rel.target_table}"\n        lines.append(f"- {source_full}.{rel.source_column} -> {target_full}.{rel.target_column}")\n        if getattr(rel, "condition_sql", ""):\n            lines.append(f"  - Condition: {rel.condition_sql}")\n        if getattr(rel, "description", ""):\n            lines.append(f"  - Description: {rel.description}")\n    return chr(10).join(lines)\n\n\ndef _fallback_json_export(state: ErdState) -> str:\n    payload = {\n        "tables": [\n            {\n                "schema_name": table.schema_name,\n                "table_name": table.table_name,\n                "full_name": table.full_name,\n                "columns": [\n                    {\n                        "column_name": col.column_name,\n                        "data_type": col.data_type,\n                        "is_primary_key": col.is_primary_key,\n                        "ordinal_position": col.ordinal_position,\n                    }\n                    for col in table.columns\n                ],\n            }\n            for table in state.tables.values()\n        ],\n        "relationships": [\n            {\n                "id": rel.id,\n                "source_schema": rel.source_schema,\n                "source_table": rel.source_table,\n                "source_column": rel.source_column,\n                "target_schema": rel.target_schema,\n                "target_table": rel.target_table,\n                "target_column": rel.target_column,\n                "relationship_type": rel.relationship_type,\n                "cardinality": rel.cardinality,\n                "join_type": rel.join_type,\n                "condition_sql": rel.condition_sql,\n                "description": rel.description,\n                "active": rel.active,\n            }\n            for rel in state.relationships.values()\n        ],\n    }\n    return json.dumps(payload, indent=2, ensure_ascii=False)\n\n\ndef render_export_tab(state: ErdState) -> None:\n    import json\n\n    from quality_checks import build_export_quality_report, report_to_issue_rows\n\n    st.subheader("Export for ChatGPT")\n    st.caption("Export database and relationship context for SQL/query generation support.")\n\n    active_ctx = _get_active_context_for_export(state)\n\n    scope_options = ["Whole database"]\n    if active_ctx:\n        scope_options.append("Active relationship context")\n\n    default_index = 1 if active_ctx else 0\n    export_scope = st.radio(\n        "Export scope",\n        scope_options,\n        index=default_index,\n        horizontal=True,\n        help="Choose whether to export the whole imported schema or only the active relationship context.",\n        key="export_quality_scope",\n    )\n\n    export_state, context_id, scope_name = _build_export_state_for_scope(state, export_scope)\n\n    if export_scope == "Active relationship context" and not active_ctx:\n        st.warning("No active relationship context is selected. Exporting the whole database instead.")\n\n    st.info(f"Current export scope: {scope_name}")\n\n    report = build_export_quality_report(state, context_id=context_id)\n    _render_export_quality_panel(report)\n\n    try:\n        from logger import log_info, log_warning\n\n        if report.get("warnings"):\n            log_warning(\n                "Export",\n                "quality_report_generated",\n                "Export quality report generated with warnings",\n                report,\n            )\n        else:\n            log_info(\n                "Export",\n                "quality_report_generated",\n                "Export quality report generated successfully",\n                report,\n            )\n    except Exception:\n        pass\n\n    st.divider()\n\n    export_format = st.selectbox(\n        "Export format",\n        ["Markdown", "JSON", "Mermaid"],\n        help="Markdown is usually best for ChatGPT. JSON is best for structured processing. Mermaid is useful for ERD text.",\n        key="export_quality_format",\n    )\n\n    include_only_active = st.checkbox(\n        "Only include active relationships",\n        value=True,\n        help="Exclude inactive relationships from the export output where supported.",\n        key="export_quality_only_active",\n    )\n\n    if export_format == "Markdown":\n        try:\n            if context_id:\n                output = _safe_call_export(export_markdown_with_context, state, context_id, include_only_active)\n            else:\n                output = _safe_call_export(export_markdown, export_state, include_only_active)\n        except Exception:\n            output = _fallback_markdown_export(export_state)\n        file_name = "entity_relation_mapper_export.md"\n        mime = "text/markdown"\n        language = "markdown"\n\n    elif export_format == "JSON":\n        try:\n            if context_id:\n                output = _safe_call_export(export_json_with_context, state, context_id, include_only_active)\n            else:\n                output = _safe_call_export(export_json, export_state, include_only_active)\n            if not isinstance(output, str):\n                output = json.dumps(output, indent=2, ensure_ascii=False)\n        except Exception:\n            output = _fallback_json_export(export_state)\n        file_name = "entity_relation_mapper_export.json"\n        mime = "application/json"\n        language = "json"\n\n    else:\n        try:\n            output = _safe_call_export(export_mermaid, export_state, include_only_active)\n        except Exception:\n            output = "erDiagram"\n        file_name = "entity_relation_mapper_export.mmd"\n        mime = "text/plain"\n        language = "mermaid"\n\n    with st.expander("Preview export output", expanded=True):\n        st.code(output, language=language)\n\n    st.download_button(\n        f"Download {export_format} export",\n        data=output,\n        file_name=file_name,\n        mime=mime,\n    )\n\n    try:\n        from logger import log_info, log_warning\n\n        details = {\n            "format": export_format,\n            "scope": scope_name,\n            "score": report.get("score"),\n            "status": report.get("status"),\n            "warning_count": len(report.get("warnings", [])),\n        }\n\n        if report.get("warnings"):\n            log_warning("Export", "export_generated_with_warnings", "Export generated with warnings", details)\n        else:\n            log_info("Export", "export_generated", "Export generated successfully", details)\n    except Exception:\n        pass\n'

CHANGELOG_ENTRY = """{
        "version": "v2.2.6 Patch",
        "title": "Export Quality Checks and Context Completeness",
        "changes": [
            "Added quality_checks.py for export readiness analysis.",
            "Added export readiness checklist to the Export for ChatGPT tab.",
            "Added relationship completeness score and quality status label.",
            "Added detection for broken relationships, missing descriptions, disconnected tables, and missing conditional SQL.",
            "Added warning panel for incomplete exports without blocking export generation.",
            "Added optional logging for export quality reports and export generation."
        ],
    },"""

CHANGELOG_MD_ENTRY = """## v2.2.6 Patch — Export Quality Checks and Context Completeness

### Added
- `quality_checks.py`.
- Export readiness checklist.
- Relationship completeness score.
- Context quality summary.
- Warning panel for incomplete exports.
- Missing-description detection.
- Tables-without-relationships detection.
- Conditional relationship quality checks.

### Changed
- Export tab now provides quality guidance before exporting.
- Export remains user-controlled and does not block output.

### Preserved
- Existing Markdown, JSON, and Mermaid export workflows.
- Existing context-scoped export.
- Existing saved-state compatibility.

---
"""


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def write_quality_module(app_dir: Path) -> None:
    write_text(app_dir / "quality_checks.py", QUALITY_CHECKS_PY)


def update_ui_export(path: Path) -> None:
    text = read_text(path)

    imports = [
        "import json",
        "import pandas as pd",
    ]

    for import_line in imports:
        if import_line not in text:
            text = import_line + "\n" + text

    marker = "# -----------------------------------------------------------------------------\n# v2.2.6 Export quality checks override"
    if marker in text:
        text = text[: text.index(marker)].rstrip() + "\n\n" + UI_EXPORT_OVERRIDE
    else:
        text = text.rstrip() + "\n\n" + UI_EXPORT_OVERRIDE

    write_text(path, text)


def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.6"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Export Quality Checks and Context Completeness"',
        text,
        count=1,
    )
    if "v2.2.6 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)
    write_text(path, text)


def update_changelog(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "v2.2.6 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    write_text(path, text)


def update_version(path: Path) -> None:
    if not path.exists():
        return
    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.6 Patch\n\nVersion Name: Export Quality Checks and Context Completeness\n\nStatus: Export readiness checklist and relationship completeness scoring added.\n",
    )


def update_readme(path: Path) -> None:
    if not path.exists():
        return

    text = read_text(path)
    if "Export Quality Checks" not in text:
        text += "\n\n## Export Quality Checks\n\nThe Export for ChatGPT tab includes an export readiness checklist and completeness score. It highlights broken relationships, disconnected tables, missing relationship descriptions, and conditional relationships missing condition SQL before export.\n"
    write_text(path, text)


def compile_check(app_dir: Path) -> None:
    errors = []

    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            if filename in {"logger.py", "ui_logs.py", "relationship_guidance.py"}:
                continue
            errors.append(f"Missing file: {filename}")
            continue

        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)

    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python add_export_quality_checks_v226.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()

    write_quality_module(app_dir)
    update_ui_export(app_dir / "ui_export.py")
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    update_readme(app_dir / "README.md")

    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.6 Patch - Export Quality Checks and Context Completeness")


if __name__ == "__main__":
    main()
