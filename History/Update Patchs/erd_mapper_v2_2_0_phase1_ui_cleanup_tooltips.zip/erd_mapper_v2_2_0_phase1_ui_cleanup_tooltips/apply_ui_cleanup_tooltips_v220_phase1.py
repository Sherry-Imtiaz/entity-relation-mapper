
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py",
]

FIELD_GUIDE_FUNCTION = '\ndef render_relationship_field_guide() -> None:\n    with st.expander("Relationship field guide", expanded=False):\n        st.markdown(\n            """\n| Field | Meaning |\n|---|---|\n| Source table | The table where the relationship starts. Usually the child/detail table or the table containing the foreign key. |\n| Source column | The source field used in the join. Often an ID or foreign-key-like field. |\n| Target table | The table being joined to. Usually the parent, master, or reference table. |\n| Target column | The matching field in the target table. Often a primary key or unique ID. |\n| Relationship mode | Standard relationships join directly. Conditional relationships need an additional rule such as `src.Item_Type = 3`. |\n| Cardinality | Describes how records relate between the two tables, such as many source records to one target record. |\n| Join type | Defines the SQL join style. `LEFT JOIN` keeps all source records. `INNER JOIN` only keeps matching records. |\n| Confidence | Your confidence that this relationship is correct. |\n| Condition SQL | A rule that must be true for the relationship to apply. Useful for discriminator fields like `Item_Type`. |\n| Extra Join SQL | Optional extra filter used in the join, such as active/current records only. |\n| Description | Business meaning of the relationship. This improves ChatGPT-generated SQL and future review. |\n"""\n        )\n\n'
SIDEBAR_BLOCK = '\n    with st.sidebar:\n        st.markdown("### Getting Started")\n        st.markdown(\n            """\n1. Import schema metadata\n2. Create a relationship context\n3. Assign tables to the context\n4. Add manual or conditional relationships\n5. Review the ERD\n6. Export context for ChatGPT or SQL support\n"""\n        )\n        st.divider()\n        st.caption("Tip: Start with one focused relationship context, such as Property Ownership or Payments.")\n'
CHANGELOG_ENTRY = '{\n        "version": "v2.2.0 Phase 1",\n        "title": "UI Cleanup and Tooltips",\n        "changes": [\n            "Removed development-history wording from the frontend where detected.",\n            "Added a Getting Started workflow guide in the app sidebar.",\n            "Added a relationship field guide to the Relationships tab.",\n            "Added contextual help text to relationship creation fields where possible.",\n            "Improved ERD View wording so technical implementation details are less visible.",\n            "Preserved existing relationship data model and saved-state compatibility."\n        ],\n    },'
CHANGELOG_MD_ENTRY = '## v2.2.0 Phase 1 — UI Cleanup and Tooltips\n\n### Added\n- Getting Started workflow guide in the sidebar.\n- Relationship field guide in the Relationships tab.\n- Tooltips/help text for manual relationship fields.\n\n### Changed\n- Removed development-history wording from the frontend where detected.\n- Improved ERD View wording.\n- Preserved existing relationship data model and saved-state compatibility.\n\n---\n'

def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")

def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")

def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.0"', text, count=1)
    text = re.sub(r'APP_VERSION_NAME\s*=\s*"[^"]+"', 'APP_VERSION_NAME = "UI Cleanup and Tooltips - Phase 1"', text, count=1)
    if "v2.2.0 Phase 1" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)
    write_text(path, text)

def update_app_sidebar(path: Path) -> None:
    text = read_text(path)
    if "### Getting Started" in text and "Import schema metadata" in text:
        return

    match = re.search(r'(st\.caption\([\s\S]*?APP_VERSION[\s\S]*?\)\n)', text)
    if not match:
        match = re.search(r'(st\.title\(.*?\)\n)', text)
    if match:
        text = text[:match.end()] + SIDEBAR_BLOCK + text[match.end():]
    else:
        text = re.sub(r"(def main\(\) -> None:\n)", r"\1" + SIDEBAR_BLOCK, text, count=1)
    write_text(path, text)

def clean_frontend_language(path: Path) -> None:
    text = read_text(path)
    replacements = {
        "Visual relationship creation has been removed from this tab. Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.": "Use this page to create, review, and maintain relationships for the active context.",
        "Graphviz ERD fallback": "ERD diagram",
        "Graphviz DOT source and download": "ERD source and download",
        "Mermaid ERD text and download": "Mermaid export text",
        "Streamlit Flow visualisation is not available because streamlit-flow-component is not installed. Install it with: pip install streamlit-flow-component": "The ERD diagram could not be displayed. Review the export text below or run the compile check.",
        "Streamlit Flow ERD visualisation": "ERD visualisation",
        "Graphviz is the primary ERD visualisation. Mermaid remains text/export only. Streamlit Flow visual component removed from the ERD View workflow.": "Graphviz is the primary ERD visualisation. Mermaid remains available as text/export.",
        "fallback": "supporting view",
        "legacy": "supporting",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    write_text(path, text)

def update_ui_relationships(path: Path) -> None:
    text = read_text(path)
    text = text.replace("\\n", "\n")

    if "def render_relationship_field_guide(" not in text:
        text = text.rstrip() + "\n\n" + FIELD_GUIDE_FUNCTION

    if "render_relationship_field_guide()" not in text:
        marker = 'st.markdown("### Add relationship from active context")'
        if marker in text:
            text = text.replace(marker, marker + "\n    render_relationship_field_guide()", 1)
        else:
            text = re.sub(r"(def render_relationships_tab\(state: ErdState\) -> None:\n)", r"\1    render_relationship_field_guide()\n", text, count=1)

    targeted_replacements = {
        'key="manual_picklist_source_table",\n        )': 'key="manual_picklist_source_table",\n            help="The table where the relationship starts. Usually the child/detail table or the table containing the foreign key.",\n        )',
        'key="manual_picklist_source_column",\n        )': 'key="manual_picklist_source_column",\n            help="The source field used in the join. Often an ID or foreign-key-like field.",\n        )',
        'key="manual_picklist_target_table",\n        )': 'key="manual_picklist_target_table",\n            help="The table being joined to. Usually the parent, master, or reference table.",\n        )',
        'key="manual_picklist_target_column",\n        )': 'key="manual_picklist_target_column",\n            help="The matching field in the target table. Often a primary key or unique ID.",\n        )',
        'key="manual_picklist_relationship_mode",\n        )': 'key="manual_picklist_relationship_mode",\n            help="Use Standard for direct joins. Use Conditional when an extra rule is required, such as src.Item_Type = 3.",\n        )',
        'key="manual_picklist_cardinality",\n        )': 'key="manual_picklist_cardinality",\n            help="Describes how records relate between source and target tables. Many-to-one is common for detail-to-master joins.",\n        )',
        'key="manual_picklist_join_type",\n        )': 'key="manual_picklist_join_type",\n            help="LEFT JOIN keeps all source records. INNER JOIN only returns matching records.",\n        )',
        'key="manual_picklist_condition_sql",\n        )': 'key="manual_picklist_condition_sql",\n            help="Extra rule required for this relationship to be valid. Use this for discriminator fields such as Item_Type.",\n        )',
        'key="manual_picklist_extra_join_sql",\n    )': 'key="manual_picklist_extra_join_sql",\n        help="Optional extra SQL filter for the join, such as active/current records only.",\n    )',
        'key="manual_picklist_description",\n    )': 'key="manual_picklist_description",\n        help="Describe the business meaning of the relationship. This improves future SQL generation and review.",\n    )',
    }
    for old, new in targeted_replacements.items():
        if old in text and new not in text:
            text = text.replace(old, new, 1)
    write_text(path, text)

def update_ui_erd(path: Path) -> None:
    text = read_text(path)
    text = text.replace("\\n", "\n")
    text = text.replace(
        "Graphviz ERD view. Table nodes show a compact schema preview with a maximum of 10 prioritised fields per table.",
        "ERD diagram view. Each table shows a compact schema preview with a maximum of 10 prioritised fields.",
    )
    text = text.replace("Graphviz DOT source and download", "ERD source and download")
    text = text.replace("Download Graphviz DOT", "Download ERD source")
    write_text(path, text)

def update_markdown_file(path: Path, version: bool = False, changelog: bool = False) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if changelog and "v2.2.0 Phase 1" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    if version:
        text = "# Version\n\nCurrent Version: v2.2.0 Phase 1\n\nVersion Name: UI Cleanup and Tooltips\n\nStatus: UI wording cleaned, Getting Started sidebar added, and relationship field guidance added.\n"
    text = text.replace("Graphviz is the primary ERD visualisation. Mermaid remains text/export only. Streamlit Flow visual component removed from the ERD View workflow.", "Graphviz is the primary ERD visualisation. Mermaid remains available as text/export.")
    write_text(path, text)

def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")
    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("\nCompile check passed.")

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python apply_ui_cleanup_tooltips_v220_phase1.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    update_config(app_dir / "config.py")
    update_app_sidebar(app_dir / "app.py")

    for name in ["ui_relationships.py", "ui_erd.py", "ui_export.py", "ui_contexts.py", "ui_tables.py", "ui_inference.py"]:
        path = app_dir / name
        if path.exists():
            clean_frontend_language(path)

    update_ui_relationships(app_dir / "ui_relationships.py")
    update_ui_erd(app_dir / "ui_erd.py")
    update_markdown_file(app_dir / "README.md")
    update_markdown_file(app_dir / "CHANGELOG.md", changelog=True)
    update_markdown_file(app_dir / "VERSION.md", version=True)
    compile_check(app_dir)
    print("\nPatch applied successfully.")
    print("Version: v2.2.0 Phase 1 - UI Cleanup and Tooltips")

if __name__ == "__main__":
    main()
