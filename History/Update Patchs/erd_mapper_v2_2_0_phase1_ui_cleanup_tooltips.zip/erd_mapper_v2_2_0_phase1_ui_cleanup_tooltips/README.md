# Entity Relation Mapper — v2.2.0 Phase 1 UI Cleanup and Tooltips

This patch polishes the frontend without changing the data model.

## Adds

- Getting Started workflow guide in the sidebar.
- Relationship field guide in the Relationships tab.
- Tooltips/help text for manual relationship fields.
- Cleaner ERD View wording.

## How to apply

```bash
python apply_ui_cleanup_tooltips_v220_phase1.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.2.0 Phase 1 — UI Cleanup and Tooltips`
