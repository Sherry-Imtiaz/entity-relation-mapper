
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py",
    "config.py",
    "models.py",
    "state_manager.py",
    "importers.py",
    "validation.py",
    "inference.py",
    "exports.py",
    "visualisation.py",
    "ui_shared.py",
    "ui_contexts.py",
    "ui_tables.py",
    "ui_relationships.py",
    "ui_inference.py",
    "ui_erd.py",
    "ui_export.py",
]

PICKLIST_HELPER = '''
def render_context_manual_relationship_picklist_form(state: ErdState) -> None:
    st.markdown("### Add relationship from active context")

    active_ctx = get_active_context(state)
    if not active_ctx:
        relationship_context_warning(state)
        return

    scoped_tables = get_context_tables(state, active_ctx.id)
    if len(scoped_tables) < 2:
        relationship_context_warning(state)
        st.info("Add at least two tables to the active relationship context before creating relationships.")
        return

    st.info(f"Relationship creation scope: {active_ctx.name} - {len(scoped_tables)} assigned tables")

    table_options = sorted(scoped_tables.keys(), key=str.lower)
    schema_options = ["All schemas"] + sorted(
        {scoped_tables[t].schema_name or "(no schema)" for t in table_options},
        key=str.lower,
    )

    col_source, col_target = st.columns(2)

    with col_source:
        st.markdown("**Source**")
        source_schema_filter = st.selectbox(
            "Source schema filter",
            schema_options,
            key="manual_picklist_source_schema_filter",
        )
        source_search = st.text_input(
            "Search source table",
            placeholder="Type to filter source tables",
            key="manual_picklist_source_search",
        )

        source_options = table_options
        if source_schema_filter != "All schemas":
            source_options = [
                t for t in source_options
                if (scoped_tables[t].schema_name or "(no schema)") == source_schema_filter
            ]
        if source_search.strip():
            source_options = [
                t for t in source_options
                if source_search.strip().lower() in t.lower()
            ]
        if not source_options:
            source_options = table_options

        source_full = st.selectbox(
            "Source table",
            source_options,
            key="manual_picklist_source_table",
        )
        source_columns = get_table_columns(state, source_full)
        source_col = st.selectbox(
            "Source column",
            source_columns,
            key="manual_picklist_source_column",
        )

    with col_target:
        st.markdown("**Target**")
        target_schema_filter = st.selectbox(
            "Target schema filter",
            schema_options,
            key="manual_picklist_target_schema_filter",
        )
        target_search = st.text_input(
            "Search target table",
            placeholder="Type to filter target tables",
            key="manual_picklist_target_search",
        )

        target_options = table_options
        if target_schema_filter != "All schemas":
            target_options = [
                t for t in target_options
                if (scoped_tables[t].schema_name or "(no schema)") == target_schema_filter
            ]
        if target_search.strip():
            target_options = [
                t for t in target_options
                if target_search.strip().lower() in t.lower()
            ]
        if not target_options:
            target_options = table_options

        target_full = st.selectbox(
            "Target table",
            target_options,
            key="manual_picklist_target_table",
        )
        target_columns = get_table_columns(state, target_full)
        target_col = st.selectbox(
            "Target column",
            target_columns,
            key="manual_picklist_target_column",
        )

    options_col1, options_col2, options_col3 = st.columns(3)

    with options_col1:
        relationship_mode = st.selectbox(
            "Relationship mode",
            ["Standard relationship", "Conditional relationship"],
            key="manual_picklist_relationship_mode",
        )
    with options_col2:
        cardinality = st.selectbox(
            "Cardinality",
            ["many-to-one", "one-to-many", "one-to-one", "many-to-many"],
            key="manual_picklist_cardinality",
        )
    with options_col3:
        join_type = st.selectbox(
            "Join type",
            ["LEFT JOIN", "INNER JOIN", "RIGHT JOIN", "FULL OUTER JOIN"],
            key="manual_picklist_join_type",
        )

    confidence = st.slider(
        "Confidence",
        min_value=0.0,
        max_value=1.0,
        value=1.0,
        step=0.05,
        key="manual_picklist_confidence",
    )

    condition_sql = ""
    if relationship_mode == "Conditional relationship":
        condition_sql = st.text_input(
            "Condition SQL",
            placeholder="Example: src.Item_Type = 3",
            key="manual_picklist_condition_sql",
        )

    extra_join_sql = st.text_input(
        "Extra Join SQL, optional",
        placeholder="Example: src.ValidTo IS NULL",
        key="manual_picklist_extra_join_sql",
    )

    description = st.text_area(
        "Description / business meaning",
        placeholder="Explain what this relationship means in business/database terms.",
        key="manual_picklist_description",
    )

    with st.expander("Relationship preview", expanded=False):
        preview = f"{source_full}.{source_col} -> {target_full}.{target_col}"
        if condition_sql.strip():
            preview += f"\\\\nCondition: {condition_sql}"
        if extra_join_sql.strip():
            preview += f"\\\\nExtra join: {extra_join_sql}"
        st.code(preview, language="text")

    if st.button("Add relationship from picklists", type="primary", key="manual_picklist_add_relationship"):
        if source_full == target_full and source_col == target_col:
            st.warning("Source and target are the same table/column. Confirm this is intentional before saving.")
            return

        ss, stbl = split_full_table(source_full)
        ts, ttbl = split_full_table(target_full)
        relationship_type = "conditional" if condition_sql.strip() else "manual"

        rid = rel_id(
            ss,
            stbl,
            source_col,
            ts,
            ttbl,
            target_col,
            relationship_type,
            condition_sql,
        )

        state.relationships[rid] = Relationship(
            id=rid,
            context_id=active_ctx.id,
            source_schema=ss,
            source_table=stbl,
            source_column=source_col,
            target_schema=ts,
            target_table=ttbl,
            target_column=target_col,
            relationship_type=relationship_type,
            cardinality=cardinality,
            join_type=join_type,
            confidence=confidence,
            condition_sql=condition_sql,
            extra_join_sql=extra_join_sql,
            description=description,
        )

        save_state(state)
        st.success("Relationship added to the active context.")
        st.rerun()

'''


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def update_ui_relationships(ui_relationships_file: Path) -> None:
    text = read_text(ui_relationships_file)

    # Clean any known literal newline artefacts first.
    text = text.replace("\\\\n", "\n")

    if "def render_context_manual_relationship_picklist_form(" not in text:
        text = text.rstrip() + "\n\n" + PICKLIST_HELPER

    if "render_context_manual_relationship_picklist_form(state)" not in text:
        marker = 'st.subheader("Relationship registry")'
        if marker in text:
            text = text.replace(
                marker,
                marker + '\n        render_context_manual_relationship_picklist_form(state)\n        st.divider()',
                1,
            )
        else:
            text = re.sub(
                r"(def render_relationships_tab\(state: ErdState\) -> None:\n)",
                r"\1    render_context_manual_relationship_picklist_form(state)\n    st.divider()\n",
                text,
                count=1,
            )

    write_text(ui_relationships_file, text)


def update_config(config_file: Path) -> None:
    text = read_text(config_file)
    text = text.replace("\\\\n", "\n")

    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.1.6"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Context-Based Manual Relationship Picklists"',
        text,
        count=1,
    )

    changelog_entry = '''{
        "version": "v2.1.6 Patch",
        "title": "Context-Based Manual Relationship Picklists",
        "changes": [
            "Added context-scoped source table dropdown for manual relationship creation.",
            "Added context-scoped target table dropdown for manual relationship creation.",
            "Added source and target column dropdowns based on the selected context tables.",
            "Added schema filters and table search fields for source and target picklists.",
            "Kept standard and conditional relationship creation in the same Relationships workflow.",
            "Restricted manual relationship creation to tables assigned to the active relationship context."
        ],
    },'''

    if "v2.1.6 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + changelog_entry, 1)

    write_text(config_file, text)


def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)

    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python add_context_manual_relationship_picklists.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    ui_relationships_file = app_dir / "ui_relationships.py"
    config_file = app_dir / "config.py"

    if not ui_relationships_file.exists():
        raise FileNotFoundError(f"Missing ui_relationships.py: {ui_relationships_file}")
    if not config_file.exists():
        raise FileNotFoundError(f"Missing config.py: {config_file}")

    update_ui_relationships(ui_relationships_file)
    update_config(config_file)
    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.1.6 Patch - Context-Based Manual Relationship Picklists")


if __name__ == "__main__":
    main()
