# Entity Relation Mapper — v2.1.6 Context-Based Manual Relationship Picklists

This patch updates the Manual Relationship workflow so relationship creation uses dropdown picklists from the active relationship context.

## What it adds

- Context-scoped source table dropdown.
- Context-scoped target table dropdown.
- Source column dropdown based on selected source table.
- Target column dropdown based on selected target table.
- Schema filters for source and target tables.
- Table search fields for source and target tables.
- Standard/conditional relationship mode in the same form.

## How to apply

```bash
python add_context_manual_relationship_picklists.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.1.6 Patch — Context-Based Manual Relationship Picklists`
