
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path


PYTHON_FILES = [
    "app.py",
    "config.py",
    "models.py",
    "state_manager.py",
    "importers.py",
    "validation.py",
    "inference.py",
    "exports.py",
    "visualisation.py",
    "ui_shared.py",
    "ui_contexts.py",
    "ui_tables.py",
    "ui_relationships.py",
    "ui_inference.py",
    "ui_erd.py",
    "ui_export.py",
    "logger.py",
    "ui_logs.py",
    "relationship_guidance.py",
    "quality_checks.py",
]


CHANGELOG_ENTRY = """{
        "version": "v2.2.7 Patch",
        "title": "Export Future Import Order Fix",
        "changes": [
            "Fixed ui_export.py import order so from __future__ import annotations appears at the top of the file.",
            "Removed duplicate future imports from ui_export.py if present.",
            "Preserved export quality checks and context completeness functionality.",
            "Re-ran compile validation across the modular project files."
        ],
    },"""


CHANGELOG_MD_ENTRY = """## v2.2.7 Patch — Export Future Import Order Fix

### Fixed
- Fixed `ui_export.py` import order.
- Ensured `from __future__ import annotations` is the first executable line.
- Removed duplicate future imports if present.

### Preserved
- Export readiness checklist.
- Relationship completeness score.
- Context quality summary.
- Existing export workflows.

---
"""


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def fix_future_import_order(path: Path) -> None:
    text = read_text(path)

    # Normalise line endings while keeping content readable.
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    future_line = "from __future__ import annotations"

    # Remove all existing future import occurrences, wherever they are.
    lines = [line for line in text.split("\n") if line.strip() != future_line]

    # Remove leading blank lines so the future import is truly first.
    while lines and not lines[0].strip():
        lines.pop(0)

    # Preserve an optional module docstring at the very top only if it exists.
    # In this project file, it is safer to put the future import first because the file is a generated UI module.
    new_text = future_line + "\n\n" + "\n".join(lines).lstrip("\n")

    # Remove accidental duplicate simple imports caused by earlier patching.
    for import_line in ["import json", "import pandas as pd"]:
        seen = False
        cleaned_lines = []
        for line in new_text.split("\n"):
            if line.strip() == import_line:
                if seen:
                    continue
                seen = True
            cleaned_lines.append(line)
        new_text = "\n".join(cleaned_lines)

    write_text(path, new_text.rstrip() + "\n")


def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")

    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.7"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Export Future Import Order Fix"',
        text,
        count=1,
    )

    if "v2.2.7 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)

    write_text(path, text)


def update_changelog(path: Path) -> None:
    if not path.exists():
        return

    text = read_text(path)
    if "v2.2.7 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)

    write_text(path, text)


def update_version(path: Path) -> None:
    if not path.exists():
        return

    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.7 Patch\n\nVersion Name: Export Future Import Order Fix\n\nStatus: ui_export.py future import order repaired and export quality checks preserved.\n",
    )


def compile_check(app_dir: Path) -> None:
    errors = []

    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            if filename in {"logger.py", "ui_logs.py", "relationship_guidance.py", "quality_checks.py"}:
                continue
            errors.append(f"Missing file: {filename}")
            continue

        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)

    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python fix_ui_export_future_import_v227.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()
    ui_export_file = app_dir / "ui_export.py"

    if not ui_export_file.exists():
        raise FileNotFoundError(f"Missing ui_export.py: {ui_export_file}")

    fix_future_import_order(ui_export_file)
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.7 Patch - Export Future Import Order Fix")


if __name__ == "__main__":
    main()
