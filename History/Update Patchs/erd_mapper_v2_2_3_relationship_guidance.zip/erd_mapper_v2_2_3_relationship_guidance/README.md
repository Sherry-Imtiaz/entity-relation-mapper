# Entity Relation Mapper — v2.2.3 Relationship Guidance and Auto-Suggestions

This patch adds user-controlled relationship guidance to the manual relationship creation workflow.

## Adds

- `relationship_guidance.py`
- Suggested cardinality
- Suggested join type
- Suggested confidence
- Explanation panel for the suggestion
- Apply Suggested Options button
- Warning for same-table/self-join relationships
- Optional logging when suggestions are applied

## How to apply

```bash
python add_relationship_guidance_v223.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate and run:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

## Version

`v2.2.3 Patch — Relationship Guidance and Auto-Suggestions`
