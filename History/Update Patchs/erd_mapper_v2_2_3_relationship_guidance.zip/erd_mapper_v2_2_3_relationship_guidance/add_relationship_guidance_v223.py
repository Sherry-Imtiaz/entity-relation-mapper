
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path

PYTHON_FILES = [
    "app.py", "config.py", "models.py", "state_manager.py", "importers.py",
    "validation.py", "inference.py", "exports.py", "visualisation.py",
    "ui_shared.py", "ui_contexts.py", "ui_tables.py", "ui_relationships.py",
    "ui_inference.py", "ui_erd.py", "ui_export.py", "logger.py", "ui_logs.py",
    "relationship_guidance.py",
]

RELATIONSHIP_GUIDANCE_PY = '\nfrom __future__ import annotations\n\nfrom typing import Any, Dict, Optional\n\nfrom models import ColumnInfo, ErdState\n\n\ndef is_key_like_column_name(column_name: str) -> bool:\n    cname = (column_name or "").lower()\n    return (\n        cname == "id"\n        or cname.endswith("_id")\n        or cname.endswith("id")\n        or "_id_" in cname\n        or cname.endswith("_key")\n        or cname.endswith("key")\n        or "_key_" in cname\n        or cname.endswith("_code")\n        or cname.endswith("code")\n        or "_code_" in cname\n        or cname.endswith("_number")\n        or cname.endswith("number")\n        or "_number_" in cname\n        or cname.endswith("_no")\n        or cname.endswith("no")\n    )\n\n\ndef get_column_info(state: ErdState, full_table: str, column_name: str) -> Optional[ColumnInfo]:\n    table = state.tables.get(full_table)\n    if not table:\n        return None\n\n    for column in table.columns:\n        if column.column_name == column_name:\n            return column\n\n    return None\n\n\ndef suggest_relationship_options(\n    state: ErdState,\n    source_full_table: str,\n    source_column: str,\n    target_full_table: str,\n    target_column: str,\n    relationship_mode: str = "Standard relationship",\n) -> Dict[str, Any]:\n    source_info = get_column_info(state, source_full_table, source_column)\n    target_info = get_column_info(state, target_full_table, target_column)\n\n    source_pk = bool(getattr(source_info, "is_primary_key", False))\n    target_pk = bool(getattr(target_info, "is_primary_key", False))\n    source_key_like = source_pk or is_key_like_column_name(source_column)\n    target_key_like = target_pk or is_key_like_column_name(target_column)\n    matching_names = (source_column or "").lower() == (target_column or "").lower()\n    same_table = source_full_table == target_full_table\n    conditional = relationship_mode == "Conditional relationship"\n\n    suggestion = {\n        "cardinality": "many-to-one",\n        "join_type": "LEFT JOIN",\n        "confidence": 0.75,\n        "relationship_type": "conditional" if conditional else "manual",\n        "warning": "",\n        "reason": "Default recommendation for joining a detail/source table to a related target table.",\n    }\n\n    reasons = []\n\n    if same_table:\n        suggestion["warning"] = (\n            "Source and target are from the same table. This may be a self-join. "\n            "Confirm this is intentional before saving."\n        )\n        reasons.append("The source and target table are the same, so this may represent a self-join.")\n\n    if source_pk and target_pk:\n        suggestion.update(\n            {\n                "cardinality": "one-to-one",\n                "join_type": "INNER JOIN",\n                "confidence": 0.85,\n            }\n        )\n        reasons.append("Both selected columns appear to be primary keys, which often indicates a one-to-one relationship.")\n    elif target_pk or target_key_like:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.95 if (source_key_like or matching_names) else 0.90,\n            }\n        )\n        reasons.append("The target column appears to be a primary key or ID/key-like field.")\n        if source_key_like:\n            reasons.append("The source column also looks like an ID/key reference.")\n        if matching_names:\n            reasons.append("The source and target column names match.")\n    elif source_key_like and target_key_like:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.90,\n            }\n        )\n        reasons.append("Both selected columns look like ID/key-style fields.")\n    elif matching_names:\n        suggestion.update(\n            {\n                "cardinality": "many-to-one",\n                "join_type": "LEFT JOIN",\n                "confidence": 0.85,\n            }\n        )\n        reasons.append("The source and target column names match.")\n\n    if conditional:\n        suggestion["join_type"] = "LEFT JOIN"\n        suggestion["confidence"] = max(float(suggestion["confidence"]), 0.90)\n        reasons.append(\n            "Conditional relationships commonly use LEFT JOIN so source records are preserved while the condition controls valid matches."\n        )\n        reasons.append(\n            "Use conditional relationships when a shared association table links to different module types using a discriminator field such as Item_Type."\n        )\n\n    suggestion["reason"] = " ".join(reasons) if reasons else suggestion["reason"]\n    return suggestion\n'
UI_RELATIONSHIP_HELPERS = '\ndef apply_pending_relationship_suggestions() -> None:\n    """Apply pending suggestion values before widgets with those keys are created."""\n    pending_map = {\n        "pending_manual_picklist_cardinality": "manual_picklist_cardinality",\n        "pending_manual_picklist_join_type": "manual_picklist_join_type",\n        "pending_manual_picklist_confidence": "manual_picklist_confidence",\n    }\n\n    for pending_key, widget_key in pending_map.items():\n        if pending_key in st.session_state:\n            st.session_state[widget_key] = st.session_state.pop(pending_key)\n\n\ndef render_relationship_suggestion_panel(\n    state: ErdState,\n    source_full: str,\n    source_col: str,\n    target_full: str,\n    target_col: str,\n    relationship_mode: str,\n) -> None:\n    """Render suggested relationship settings for the selected source/target fields."""\n    suggestion = suggest_relationship_options(\n        state,\n        source_full,\n        source_col,\n        target_full,\n        target_col,\n        relationship_mode,\n    )\n\n    st.markdown("#### Suggested relationship options")\n\n    if suggestion.get("warning"):\n        st.warning(suggestion["warning"])\n\n    metric_col1, metric_col2, metric_col3 = st.columns(3)\n    metric_col1.metric("Suggested cardinality", suggestion["cardinality"])\n    metric_col2.metric("Suggested join", suggestion["join_type"])\n    metric_col3.metric("Suggested confidence", f\'{float(suggestion["confidence"]):.2f}\')\n\n    with st.expander("Why these options are suggested", expanded=False):\n        st.write(suggestion["reason"])\n\n    if st.button(\n        "Apply suggested options",\n        key="manual_picklist_apply_suggestion",\n        help="Apply the suggested cardinality, join type, and confidence to the relationship form.",\n    ):\n        st.session_state["pending_manual_picklist_cardinality"] = suggestion["cardinality"]\n        st.session_state["pending_manual_picklist_join_type"] = suggestion["join_type"]\n        st.session_state["pending_manual_picklist_confidence"] = float(suggestion["confidence"])\n\n        try:\n            from logger import log_info\n\n            log_info(\n                "Relationships",\n                "suggestion_applied",\n                "Relationship suggestion applied",\n                {\n                    "source": f"{source_full}.{source_col}",\n                    "target": f"{target_full}.{target_col}",\n                    "suggestion": suggestion,\n                },\n            )\n        except Exception:\n            pass\n\n        st.success("Suggested options applied.")\n        st.rerun()\n\n'
PANEL_CALL = '    render_relationship_suggestion_panel(\n        state,\n        source_full,\n        source_col,\n        target_full,\n        target_col,\n        relationship_mode,\n    )\n\n'
CHANGELOG_ENTRY = '{\n        "version": "v2.2.3 Patch",\n        "title": "Relationship Guidance and Auto-Suggestions",\n        "changes": [\n            "Added relationship_guidance.py for relationship option recommendations.",\n            "Added suggested cardinality, join type, and confidence guidance to the Relationships tab.",\n            "Added an Apply Suggested Options button for manual relationship creation.",\n            "Added warning guidance for same-table/self-join relationships.",\n            "Added logging when suggested relationship options are applied.",\n            "Preserved user control by not automatically overwriting relationship form selections."\n        ],\n    },'
CHANGELOG_MD_ENTRY = '## v2.2.3 Patch — Relationship Guidance and Auto-Suggestions\n\n### Added\n- `relationship_guidance.py`.\n- Suggested cardinality, join type, and confidence recommendations.\n- Relationship explanation panel.\n- Apply Suggested Options button.\n- Same-table/self-join warning.\n- Logging when suggested options are applied.\n\n### Preserved\n- Existing manual relationship workflow.\n- Existing conditional relationship workflow.\n- Existing saved-state compatibility.\n- Existing ERD/export behaviour.\n\n---\n'


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def write_relationship_guidance(app_dir: Path) -> None:
    write_text(app_dir / "relationship_guidance.py", RELATIONSHIP_GUIDANCE_PY)


def update_ui_relationships(path: Path) -> None:
    text = read_text(path)

    if "from relationship_guidance import suggest_relationship_options" not in text:
        if "from ui_shared import *" in text:
            text = text.replace(
                "from ui_shared import *",
                "from ui_shared import *\nfrom relationship_guidance import suggest_relationship_options",
                1,
            )
        else:
            text = "from relationship_guidance import suggest_relationship_options\n" + text

    if "def apply_pending_relationship_suggestions(" not in text:
        text = text.rstrip() + "\n\n" + UI_RELATIONSHIP_HELPERS

    if "apply_pending_relationship_suggestions()" not in text:
        marker = 'st.markdown("### Add relationship from active context")'
        if marker in text:
            text = text.replace(marker, marker + "\n    apply_pending_relationship_suggestions()", 1)
        else:
            marker = "def render_context_manual_relationship_picklist_form(state: ErdState) -> None:\n"
            if marker in text:
                text = text.replace(marker, marker + "    apply_pending_relationship_suggestions()\n", 1)

    if "render_relationship_suggestion_panel(\n        state,\n        source_full," not in text:
        marker = '    condition_sql = ""\n'
        if marker in text:
            text = text.replace(marker, PANEL_CALL + marker, 1)
        else:
            marker = "    extra_join_sql = st.text_input(\n"
            if marker in text:
                text = text.replace(marker, PANEL_CALL + marker, 1)

    write_text(path, text)


def update_config(path: Path) -> None:
    text = read_text(path)
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.3"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Relationship Guidance and Auto-Suggestions"',
        text,
        count=1,
    )
    if "v2.2.3 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)
    write_text(path, text)


def update_changelog(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "v2.2.3 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    write_text(path, text)


def update_version(path: Path) -> None:
    if not path.exists():
        return
    write_text(
        path,
        "# Version\n\nCurrent Version: v2.2.3 Patch\n\nVersion Name: Relationship Guidance and Auto-Suggestions\n\nStatus: Relationship creation now includes suggested join/cardinality/confidence guidance.\n",
    )


def update_readme(path: Path) -> None:
    if not path.exists():
        return
    text = read_text(path)
    if "Relationship Guidance" not in text:
        text += "\n\n## Relationship Guidance\n\nThe Relationships tab can suggest cardinality, join type, and confidence values based on the selected source and target fields. Suggestions are user-controlled and only apply when you select **Apply suggested options**.\n"
    write_text(path, text)


def compile_check(app_dir: Path) -> None:
    errors = []
    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            if filename in {"logger.py", "ui_logs.py"}:
                continue
            errors.append(f"Missing file: {filename}")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("\nCompile check passed.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python add_relationship_guidance_v223.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()

    write_relationship_guidance(app_dir)
    update_ui_relationships(app_dir / "ui_relationships.py")
    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version(app_dir / "VERSION.md")
    update_readme(app_dir / "README.md")
    compile_check(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.3 Patch - Relationship Guidance and Auto-Suggestions")


if __name__ == "__main__":
    main()
