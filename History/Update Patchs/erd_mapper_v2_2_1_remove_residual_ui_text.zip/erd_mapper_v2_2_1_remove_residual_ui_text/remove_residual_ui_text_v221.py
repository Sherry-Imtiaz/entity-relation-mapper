
from __future__ import annotations

import py_compile
import re
import sys
from pathlib import Path


PYTHON_FILES = [
    "app.py",
    "config.py",
    "models.py",
    "state_manager.py",
    "importers.py",
    "validation.py",
    "inference.py",
    "exports.py",
    "visualisation.py",
    "ui_shared.py",
    "ui_contexts.py",
    "ui_tables.py",
    "ui_relationships.py",
    "ui_inference.py",
    "ui_erd.py",
    "ui_export.py",
]


SCAN_FILES = [
    "app.py",
    "ui_shared.py",
    "ui_contexts.py",
    "ui_tables.py",
    "ui_relationships.py",
    "ui_inference.py",
    "ui_erd.py",
    "ui_export.py",
]


BAD_PHRASES = [
    "Visual relationship creation has been removed from this tab. Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.",
    "Visual relationship creation has been removed from this tab.",
    "Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.",
    "interactive Streamlit Flow visualisation",
    "Streamlit Flow visualisation",
    "Streamlit Flow ERD visualisation",
    "Streamlit Flow visual component removed",
    "visual component removed",
    "Graphviz fallback",
    "legacy visualisation",
]


CLEAN_RELATIONSHIP_MESSAGE = "Use this page to create, review, and maintain relationships for the active context."
CHANGELOG_ENTRY = '{\n        "version": "v2.2.1 Patch",\n        "title": "Remove Residual Development UI Text",\n        "changes": [\n            "Removed remaining frontend text that referenced removed visual relationship creation.",\n            "Removed remaining Streamlit Flow implementation wording from user-facing UI files where detected.",\n            "Replaced internal implementation-history messages with clean user guidance.",\n            "Preserved existing app behaviour and relationship data model."\n        ],\n    },'
CHANGELOG_MD_ENTRY = '## v2.2.1 Patch — Remove Residual Development UI Text\n\n### Fixed\n- Removed remaining frontend text that referenced removed visual relationship creation.\n- Removed residual Streamlit Flow implementation wording where detected.\n- Replaced internal implementation-history messages with clean user-facing guidance.\n\n---\n'


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def clean_literal_newline_artifacts(text: str) -> str:
    text = text.replace("APP_CHANGELOG = [\\n", "APP_CHANGELOG = [\n")
    return text


def clean_ui_file(path: Path) -> bool:
    original = read_text(path)
    text = clean_literal_newline_artifacts(original)

    text = text.replace(
        "Visual relationship creation has been removed from this tab. Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.",
        CLEAN_RELATIONSHIP_MESSAGE,
    )

    replacements = {
        "Visual relationship creation has been removed from this tab.": CLEAN_RELATIONSHIP_MESSAGE,
        "Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.": "",
        "interactive Streamlit Flow visualisation": "ERD diagram",
        "Streamlit Flow visualisation": "ERD visualisation",
        "Streamlit Flow ERD visualisation": "ERD visualisation",
        "Streamlit Flow visual component removed": "ERD visualisation updated",
        "visual component removed": "visualisation updated",
        "Graphviz fallback": "ERD diagram",
        "legacy visualisation": "supporting visualisation",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    noisy_terms = [
        "Visual relationship creation has been removed",
        "Streamlit Flow visualisation",
        "Streamlit Flow ERD visualisation",
        "interactive Streamlit Flow visualisation",
        "visual component removed",
        "Graphviz fallback",
        "legacy visualisation",
    ]

    for term in noisy_terms:
        pattern = (
            r"st\.(info|warning|caption|write|markdown)\("
            r"(?:(?!\n\s*(?:if |for |with |def |class |elif |else:|try:|except |finally:|return |st\.|[A-Za-z_][A-Za-z0-9_]*\s*=)).)*?"
            + re.escape(term)
            + r".*?\)"
        )
        text = re.sub(pattern, f'st.info("{CLEAN_RELATIONSHIP_MESSAGE}")', text, flags=re.DOTALL)

    if path.name == "ui_relationships.py":
        if CLEAN_RELATIONSHIP_MESSAGE not in text:
            marker = 'def render_relationships_tab(state: ErdState) -> None:\n'
            if marker in text:
                text = text.replace(
                    marker,
                    marker + f'    st.info("{CLEAN_RELATIONSHIP_MESSAGE}")\n',
                    1,
                )

    changed = text != original
    if changed:
        write_text(path, text)
    return changed


def update_config(config_file: Path) -> None:
    text = read_text(config_file)
    text = clean_literal_newline_artifacts(text)

    text = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "v2.2.1"', text, count=1)
    text = re.sub(
        r'APP_VERSION_NAME\s*=\s*"[^"]+"',
        'APP_VERSION_NAME = "Remove Residual Development UI Text"',
        text,
        count=1,
    )

    if "v2.2.1 Patch" not in text:
        text = text.replace("APP_CHANGELOG = [", "APP_CHANGELOG = [\n    " + CHANGELOG_ENTRY, 1)

    write_text(config_file, text)


def update_changelog(changelog_file: Path) -> None:
    if not changelog_file.exists():
        return

    text = read_text(changelog_file)
    if "v2.2.1 Patch" not in text:
        text = text.replace("# Entity Relation Mapper — Changelog\n", "# Entity Relation Mapper — Changelog\n\n" + CHANGELOG_MD_ENTRY, 1)
    write_text(changelog_file, text)


def update_version_file(version_file: Path) -> None:
    if not version_file.exists():
        return

    write_text(
        version_file,
        "# Version\n\nCurrent Version: v2.2.1 Patch\n\nVersion Name: Remove Residual Development UI Text\n\nStatus: Frontend implementation-history messages cleaned from UI files where detected.\n",
    )


def compile_check(app_dir: Path) -> None:
    errors = []

    for filename in PYTHON_FILES:
        path = app_dir / filename
        if not path.exists():
            errors.append(f"Missing file: {filename}")
            continue

        try:
            py_compile.compile(str(path), doraise=True)
            print(f"OK: {filename}")
        except Exception as exc:
            errors.append(f"{filename}: {exc}")

    if errors:
        print("\nCompile check failed:")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)

    print("\nCompile check passed.")


def post_patch_scan(app_dir: Path) -> None:
    remaining = []
    for filename in SCAN_FILES:
        path = app_dir / filename
        if not path.exists():
            continue
        text = read_text(path)
        for phrase in BAD_PHRASES:
            if phrase in text:
                remaining.append(f"{filename}: {phrase}")

    if remaining:
        print("\nWarning: some phrases may still remain:")
        for item in remaining:
            print(f"- {item}")
    else:
        print("\nNo residual development-history UI phrases detected in scanned files.")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python remove_residual_ui_text_v221.py <erd_mapper_folder>")
        raise SystemExit(1)

    app_dir = Path(sys.argv[1]).expanduser().resolve()

    changed_files = []
    for filename in SCAN_FILES:
        path = app_dir / filename
        if path.exists() and clean_ui_file(path):
            changed_files.append(filename)

    update_config(app_dir / "config.py")
    update_changelog(app_dir / "CHANGELOG.md")
    update_version_file(app_dir / "VERSION.md")

    compile_check(app_dir)
    post_patch_scan(app_dir)

    print("\nPatch applied successfully.")
    print("Version: v2.2.1 Patch - Remove Residual Development UI Text")
    if changed_files:
        print("Changed files:")
        for filename in changed_files:
            print(f"- {filename}")
    else:
        print("No UI files required changes based on the scan.")


if __name__ == "__main__":
    main()
