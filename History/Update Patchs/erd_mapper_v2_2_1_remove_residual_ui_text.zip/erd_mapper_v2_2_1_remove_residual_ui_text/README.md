# Entity Relation Mapper — v2.2.1 Remove Residual Development UI Text

This patch removes remaining user-facing text such as:

```text
Visual relationship creation has been removed from this tab. Use the form above to create/edit relationships, and use the ERD View tab for interactive Streamlit Flow visualisation.
```

## How to apply

```bash
python remove_residual_ui_text_v221.py "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
```

Then validate and restart Streamlit:

```bash
cd "C:\Users\sherr\Desktop\Stream\erd_mapper_v2_1_0"
python scripts\compile_check.py
streamlit run app.py
```

If Streamlit was already running, stop it and restart it after applying the patch.

## Version

`v2.2.1 Patch — Remove Residual Development UI Text`
